import React from "react";
import {
  useLocation,
  useParams,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";
import { Container } from "reactstrap";
import AdminNavbar from "components/Navbars/AdminNavbar.jsx";
import AdminFooter from "components/Footers/AdminFooter.js";
import Sidebar from "components/Sidebar/Sidebar.jsx";
import { useAuth } from "context/AuthContext";
import { clienteRoutes, barberoRoutes } from "./../routes";
import { useEmpresa } from "context/EmpresaContext";
import { filtrarRutasPermitidas } from "utils/filtrarRutas.js";
import { filtrarRutasMenu } from "utils/filtrarRutas.js";


const AdminLayout = (props) => {
  const mainContent = React.useRef(null);
  const location = useLocation();
  const { slug } = useParams();
  const { user } = useAuth();
  const { empresa, loading } = useEmpresa();

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const routes = user?.rol === "barbero" ? barberoRoutes : clienteRoutes;

  // Rutas que este usuario puede cargar (incluye las invisibles)
  const rutasPermitidas = React.useMemo(
    () => filtrarRutasPermitidas(routes, { user, slug, empresa }),
    [routes, user, slug, empresa],
  );

  // Rutas que este usuario puede ver en el menú
  const rutasMenu = React.useMemo(
    () => filtrarRutasMenu(routes, { user, slug, empresa }),
    [routes, user, slug, empresa],
  );

  // 🔥 1️⃣ Mientras carga la empresa
  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-border text-primary" />
      </div>
    );
  }

  // 🔥 2️⃣ Si no existe empresa (seguridad extra)
  if (!empresa) {
    return null;
  }

  return (
    <>
      <Sidebar
        {...props}
        routes={rutasMenu}
        logo={{
          innerLink: "/admin/index",
          imgSrc: empresa.logo,
          imgAlt: empresa.nombre || "Logo Empresa",
        }}
      />

      <div className="main-content" ref={mainContent}>
        <AdminNavbar {...props} brandText={empresa.nombre} />

        <Routes>
          {rutasPermitidas.flatMap((r, idx) =>
            r.children
              ? r.children.map((child, cidx) => (
                  <Route
                    key={`${idx}-${cidx}`}
                    path={child.path}
                    element={child.component}
                  />
                ))
              : [<Route key={idx} path={r.path} element={r.component} />],
          )}

          {/* Cualquier ruta no permitida cae acá y se redirige */}
          {user?.rol === "barbero" ? (
            <Route
              path="*"
              element={<Navigate to="/admin/dashboard" replace />}
            />
          ) : (
            <Route path="*" element={<Navigate to="/admin/index" replace />} />
          )}
        </Routes>

        <Container fluid>
          <AdminFooter />
        </Container>
      </div>
    </>
  );
};

export default AdminLayout;