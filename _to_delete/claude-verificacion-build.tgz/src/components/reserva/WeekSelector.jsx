// src/components/reserva/WeekSelector.jsx
import React from "react";
import { FormGroup, Label, Button, Spinner, Badge } from "reactstrap";
import { ChevronLeft, ChevronRight, Bell } from "lucide-react";
import { useEmpresa } from "context/EmpresaContext";
import { construirTema } from "utils/temaEmpresa";

const formatDayLabel = (d) =>
  d.toLocaleDateString("es-CL", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });

// 👉 Fecha de hoy en formato YYYY-MM-DD (LOCAL)
const todayISO = () => {
  const now = new Date();
  const local = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return local.toISOString().split("T")[0];
};

const WeekSelector = ({
  weekStart,
  weekDays,
  loadingWeek,
  fecha,
  onSelectDay,
  onPrevWeek,
  onNextWeek,
  onWaitlist,
  barberoId,
  barberoInfo,
  rolUsuario,
}) => {
  const { empresa } = useEmpresa();
  const theme = construirTema(empresa?.colores);

  const parseLocalDate = (str) => {
    const [y, m, d] = str.split("-").map(Number);
    return new Date(y, m - 1, d);
  };

  const esPrivilegiado = rolUsuario === "barbero";

  /* ===============================
     VALIDACIÓN DATA REAL (ANTI FLASH)
  =============================== */
  const weekReady =
    weekDays &&
    weekDays.length > 0 &&
    weekDays.some((d) => d.horas !== undefined);

  const hoyISO = todayISO();

  /* ===============================
     ESTADOS BASE
  =============================== */

  // 🔒 Sin barbero seleccionado
  if (!barberoId) {
    return (
      <FormGroup className="mb-4">
        <Label className="font-weight-bold">📅 Selecciona día</Label>
        <div className="alert alert-warning text-center py-3">
          <strong>Selecciona un barbero primero</strong>
          <p className="mb-0 small mt-1">
           Elige un profesional
          </p>
        </div>
      </FormGroup>
    );
  }

  // ⏳ Loading REAL (evita parpadeo de días bloqueados)
  if (loadingWeek || !weekReady) {
    return (
      <FormGroup className="mb-4">
        <Label className="font-weight-bold">
          📅 Disponibilidad de la semana
        </Label>

        <div className="d-flex flex-column align-items-center py-5">
          <Spinner size="sm" className="mb-2 text-success" />
          <span className="text-muted small">
            Cargando disponibilidad...
          </span>
        </div>
      </FormGroup>
    );
  }

  // ⚠️ Sin datos reales
  if (!weekDays || weekDays.length === 0) {
    return (
      <FormGroup className="mb-4">
        <Label className="font-weight-bold">
          📅 Disponibilidad de la semana
        </Label>
        <div className="alert alert-info text-center py-3">
          <strong>No hay datos de disponibilidad</strong>
        </div>
      </FormGroup>
    );
  }

  /* ===============================
     RENDER NORMAL
  =============================== */

  return (
    <FormGroup className="mb-4">
      {/* HEADER */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <Label className="font-weight-bold mb-0 h5">
          📅 Disponibilidad de la semana
        </Label>

        {barberoInfo && (
          <Badge color="info" pill className="px-3 py-1">
            {barberoInfo.nombre}
          </Badge>
        )}
      </div>

      {/* NAV + DÍAS */}
      <div className="d-flex align-items-center mb-3">
        <Button
          color="outline-primary"
          onClick={onPrevWeek}
          className="me-2 p-2"
          size="sm"
        >
          <ChevronLeft size={18} />
        </Button>

        <div className="flex-grow-1 overflow-auto">
          <div style={{ display: "flex", gap: "10px" }}>
            {weekDays.map((d) => {
              const isPast = !esPrivilegiado && d.iso < hoyISO;
              const isToday = d.iso === hoyISO;
              const isSelected = d.iso === fecha;

              const horasDisponibles = (d.horas || []).filter(
                (h) => h.estado === "disponible"
              );

              const diaHabilitado = d.horas && d.horas.length > 0;
              const diaTieneHoras = horasDisponibles.length > 0;
              const diaLleno = diaHabilitado && !diaTieneHoras;

              const diaBloqueado = isPast || !diaHabilitado;

              return (
                <div
                  key={d.iso}
                  style={{
                    position: "relative",
                    flex: 1,
                    minWidth: "85px",
                  }}
                >
                  {/* 🔔 WAITLIST */}
                  {!isPast && !diaHabilitado && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        onWaitlist?.({ fecha: d.iso, barberoId });
                      }}
                      style={{
                        position: "absolute",
                        top: "-8px",
                        right: "-8px",
                        backgroundColor: "#ffc107",
                        padding: "6px",
                        borderRadius: "50%",
                        cursor: "pointer",
                        zIndex: 10,
                      }}
                      title="Avisarme si se habilita"
                    >
                      <Bell size={16} />
                    </div>
                  )}

                  {/* TARJETA */}
                  <div
                    onClick={() => {
                      if (!diaBloqueado) {
                        onSelectDay(d.iso);
                      }
                    }}
                    style={{
                      padding: "12px 8px",
                      borderRadius: "12px",
                      cursor: diaBloqueado ? "not-allowed" : "pointer",
                      opacity: diaBloqueado ? 0.5 : 1,
                      backgroundColor: isSelected
                        ? theme.primary
                        : diaTieneHoras
                        ? "#ffffff"
                        : "#f8f9fa",
                      color: isSelected
                        ? "#fff"
                        : diaBloqueado
                        ? "#6c757d"
                        : "#212529",
                      border: isSelected
                        ? `2px solid ${theme.primaryDark}`
                        : "1px solid #dee2e6",
                      textAlign: "center",
                      transition: "all 0.2s ease",
                    }}
                  >
                    <div style={{ fontSize: "12px", fontWeight: 600 }}>
                      {parseLocalDate(d.iso).toLocaleDateString("es-CL", {
                        weekday: "short",
                      })}
                    </div>

                    <div style={{ fontSize: "20px", fontWeight: 700 }}>
                      {parseLocalDate(d.iso).getDate()}
                    </div>

                    <div style={{ fontSize: "11px", opacity: 0.8 }}>
                      {parseLocalDate(d.iso).toLocaleDateString("es-CL", {
                        month: "short",
                      })}
                    </div>

                    <div style={{ marginTop: "4px", fontSize: "11px" }}>
                      {isPast ? (
                        <span>Fecha pasada</span>
                      ) : diaTieneHoras ? (
                        <strong>{horasDisponibles.length} hrs</strong>
                      ) : diaLleno ? (
                        <span>Sin horas</span>
                      ) : (
                        <span>No disponible</span>
                      )}
                    </div>

                    {isToday && !isPast && (
                      <div
                        style={{
                          fontSize: "10px",
                          fontWeight: 700,
                          marginTop: "4px",
                          color: isSelected ? "#fff" : theme.primary,
                        }}
                      >
                        Hoy
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <Button
          color="outline-primary"
          onClick={onNextWeek}
          className="ms-2 p-2"
          size="sm"
        >
          <ChevronRight size={18} />
        </Button>
      </div>

      {/* FOOTER */}
      <div className="text-muted small">
        Semana del {formatDayLabel(new Date(weekStart))}
      </div>
    </FormGroup>
  );
};

export default WeekSelector;