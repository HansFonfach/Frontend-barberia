import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Col, Container, Row } from "reactstrap";
import { CalendarCheck, Cake, Users } from "lucide-react";
import { MdLocationOn, MdAccessTime, MdPhone } from "react-icons/md";
import { FaWhatsapp, FaInstagram } from "react-icons/fa";
import AuthFooter from "components/Footers/AuthFooter";
import { construirTema } from "utils/temaEmpresa";

/**
 * Landing para empresas de rubro "restaurante" (bares, restaurantes).
 * Su único objetivo es llevar a reservar mesa; el landing de barbería/salón
 * sigue intacto para el resto de los negocios.
 */
const LandingRestaurante = ({ empresa, slug }) => {
  const navigate = useNavigate();
  const theme = construirTema(empresa?.colores);
  const telefonoLimpio = (empresa?.telefono || "").replace(/\D/g, "");
  const reservar = () => navigate(`/${slug}/reservar-mesa`);

  const datos = [
    empresa?.direccion && { icono: <MdLocationOn size={22} />, texto: empresa.direccion },
    empresa?.horarios && { icono: <MdAccessTime size={22} />, texto: empresa.horarios },
    empresa?.telefono && { icono: <MdPhone size={22} />, texto: empresa.telefono, href: `tel:${telefonoLimpio}` },
  ].filter(Boolean);

  return (
    <div style={{ background: "#fff", overflowX: "hidden" }}>
      <section
        style={{ background: theme.heroBg, minHeight: "78vh", display: "flex", alignItems: "center", color: "#fff" }}
      >
        <Container>
          <Row className="justify-content-center">
            <Col lg="8" className="text-center">
              {empresa?.logo && (
                <img
                  src={empresa.logo}
                  alt={empresa.nombre}
                  style={{ width: 96, height: 96, objectFit: "cover", borderRadius: "50%", marginBottom: 24 }}
                />
              )}
              <h1 className="display-3 font-weight-bold text-white mb-3" style={{ fontSize: "clamp(2.2rem, 5vw, 3.6rem)" }}>
                {empresa.nombre}
              </h1>
              {(empresa.mensajeBienvenida || empresa.descripcion) && (
                <p className="lead mb-5" style={{ color: "rgba(255,255,255,0.85)" }}>
                  {empresa.mensajeBienvenida || empresa.descripcion}
                </p>
              )}
              <Button
                size="lg"
                onClick={reservar}
                style={{ background: theme.primary, borderColor: theme.primary, color: "#fff", padding: "14px 32px", borderRadius: 12 }}
              >
                <CalendarCheck size={20} style={{ verticalAlign: "-4px" }} /> Reservar mesa
              </Button>
            </Col>
          </Row>
        </Container>
      </section>

      <section className="py-6" style={{ background: theme.softBg }}>
        <Container>
          <Row className="justify-content-center text-center">
            <Col md="4" className="mb-4">
              <CalendarCheck size={32} color={theme.primary} />
              <h4 className="mt-3">Reserva en un minuto</h4>
              <p className="text-muted mb-0">Elige día, hora y sector. Sin crear cuenta.</p>
            </Col>
            <Col md="4" className="mb-4">
              <Users size={32} color={theme.primary} />
              <h4 className="mt-3">Para tu grupo</h4>
              <p className="text-muted mb-0">Comparte con amigos en terraza o salón, según disponibilidad.</p>
            </Col>
            <Col md="4" className="mb-4">
              <Cake size={32} color={theme.primary} />
              <h4 className="mt-3">¿Celebras algo?</h4>
              <p className="text-muted mb-0">Cuéntanos si es un cumpleaños al reservar.</p>
            </Col>
          </Row>
        </Container>
      </section>

      {(datos.length > 0 || empresa?.redes?.instagram) && (
        <section className="py-6">
          <Container>
            <Row className="justify-content-center">
              <Col lg="7">
                <h3 className="text-center mb-4">Encuéntranos</h3>
                {datos.map((d, i) => (
                  <div key={i} className="d-flex align-items-center mb-3" style={{ gap: 12, color: theme.textDark }}>
                    <span style={{ color: theme.primary }}>{d.icono}</span>
                    {d.href ? <a href={d.href}>{d.texto}</a> : <span>{d.texto}</span>}
                  </div>
                ))}
                <div className="d-flex justify-content-center mt-4" style={{ gap: 12 }}>
                  {telefonoLimpio && (
                    <a href={`https://wa.me/${telefonoLimpio}`} target="_blank" rel="noreferrer" className="btn btn-outline-success">
                      <FaWhatsapp style={{ verticalAlign: "-2px" }} /> WhatsApp
                    </a>
                  )}
                  {empresa?.redes?.instagram && (
                    <a href={empresa.redes.instagram} target="_blank" rel="noreferrer" className="btn btn-outline-secondary">
                      <FaInstagram style={{ verticalAlign: "-2px" }} /> Instagram
                    </a>
                  )}
                </div>
              </Col>
            </Row>
          </Container>
        </section>
      )}

      <div className="text-center pb-4">
        <a href={`/${slug}/login`} className="small text-muted">
          Acceso del equipo
        </a>
      </div>
      <AuthFooter />
    </div>
  );
};

export default LandingRestaurante;
