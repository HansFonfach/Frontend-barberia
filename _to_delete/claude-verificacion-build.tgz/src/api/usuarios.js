import { axiosPrivate } from "./axiosPrivate";
import { axiosPublic } from "./axiosPublic";

export const getUsuarios = () => {
  return axiosPrivate.get("/usuarios");
};

export const putUsuario = (id, data) => {
  const isFormData = data instanceof FormData;
  return axiosPrivate.put(`/usuarios/${id}`, data, {
    headers: isFormData ? { "Content-Type": "multipart/form-data" } : {},
  });
};

export const putUpdatePerfilUsuario = (data) =>
  axiosPrivate.put("/usuarios/actualizarPerfil", data);

export const getUsuarioByRut = (rut) => {
  return axiosPrivate.get(`/usuarios/rut/${rut}`);
};
export const getUsuarioByRutPublico = async (slug, rut) => {
  const res = await axiosPublic.get(`/usuarios/publico/${slug}/rut/${rut}`);
  return res.data;
};
export const postSubscribeUserById = (_id, planId) => {
  return axiosPrivate.post(`/suscripcion/usuario/${_id}/suscribir`, {
    planId,
  });
};

export const putUnsubscribeUserById = (_id) => {
  return axiosPrivate.put(`/suscripcion/usuario/${_id}/cancelarSub`);
};

export const getTodosLosUsuarios = () => {
  return axiosPrivate.get(`/usuarios/todosLosUsuarios`);
};

export const getSubActiva = () => {
  return axiosPrivate.get("/suscripcion/usuario/activa");
};

export const getVerMisPuntos = () => {
  return axiosPrivate.get("/usuarios/misPuntos");
};

export const postAsignarServiciosAlBarbero = (
  barberoId,
  serviciosAsignados,
) => {
  return axiosPrivate.post(
    `/barberoServicio/barberos/${barberoId}/servicios`,
    serviciosAsignados,
  );
};

export const postCrearBarbero = (data) => {
  return axiosPrivate.post(`/usuarios/barbero/crearBarbero`, data);
};

export const postCrearCliente = (data) => {
  return axiosPrivate.post(`/usuarios/cliente/crearCliente`, data);
};

export const updateEstadoUsuario = (id, estado) => {
  return axiosPrivate.patch(`/usuarios/${id}/estado`, { estado });
};

export const getBarberosPublico = (slug) => {
  return axiosPublic.get(`/usuarios/barbero/${slug}/barberos`);
};

export const putActualizarNota = (id, notasProfesional) => {
  return axiosPrivate.put(`/usuarios/${id}/notas`, { notasProfesional });
};

export const updateUsuarioDesdeAdmin = (id, data) => {
  return axiosPrivate.put(`/usuarios/${id}/actualizarUsuario`, data);
};

// Panel "Equipo" — listado liviano de profesionales de la empresa
// (solo trae rol=barbero, con esAdmin incluido para el selector/toggle).
export const getBarberosDeEmpresa = () => {
  return axiosPrivate.get(`/usuarios/equipo/lista`);
};
