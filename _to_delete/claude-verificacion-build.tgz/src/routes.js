// src/routes/routes.js

import Principal from "views/pages/Principal";
import ReservarHora from "views/pages/ReservarHora";
import Suscripcion from "views/pages/Suscripcion";
import Administrar from "views/pages/AdministrarReservas";
import Perfil from "views/pages/Perfil";
import AdminDashboard from "views/admin/pages/PrincipalBarbero";
import Login from "views/pages/Login";
import Register from "views/pages/Register";
import ReservarHoraBarbero from "views/admin/pages/ReservarHoraBarbero";
import CrearBarberoCompleto from "views/admin/pages/GestionBarberos";
import PanelEquipo from "views/admin/pages/PanelEquipo";
import WizardBarberoSemana from "views/admin/pages/WizardBarberos";
import GestionServicios from "views/admin/pages/GestionServicios";
import GestionCodigosDescuento from "views/admin/pages/GestionCodigosDescuento";
import GestionHorariosBarbero from "views/admin/pages/GestionHorarios";
import GestionClientes from "views/admin/pages/GestionClientes";
import ReservasDiarias from "views/admin/pages/ReservasDiarias";
import ForgotPassword from "views/publico/ForgotPassword";
import Estadisticas from "views/admin/pages/Estadisticas";
import EstadisticasServicios from "views/admin/pages/EstadisticasServicios";
import EstadisticasGimnasio from "views/admin/pages/EstadisticasGimnasio";
import BarberosPage from "views/pages/PresentarBarberos";
import CentroAyuda from "views/pages/CentroAyuda";
import Politicas from "views/pages/Politicas";
import CambiarContrasena from "views/pages/CambiarContraseña";
import ReiniciarContraseña from "views/publico/ReiniciarContraseña";
import PresentarServicios from "views/pages/PresentarServicios";
import Contacto from "views/pages/Contacto";
import SuscripcionResultado from "views/pages/SuscripcionResultado";
import CatalogoCanjes from "views/pages/CatalogoCanjes";
import GestionCanjes from "views/admin/pages/GestionCanjes";
import AsignarServiciosBarberos from "views/admin/pages/AsignarServiciosBarberos";
import Landing from "views/pages/Landing";
import ReservarHoraInvitado from "views/invitados/pages/ReservaInvitado";
import CancelarInvitado from "views/invitados/pages/CancelarInvitado";
import VerificarCuenta from "views/publico/VerificarCuenta";
import ConfiguracionEmpresa from "views/admin/ConfiguracionEmpresa";
import GestionVacaciones from "views/admin/pages/GestionVacaciones";
import RegistrarNegocio from "views/publico/RegistrarNegocio";
import ConfirmacionResultado from "views/publico/ConfirmacionResultado";
import GestionProductos from "views/admin/pages/GestionProductos";
import EstadisticasProductos from "views/admin/pages/EstadisticasProductos";
import HistorialIngresos from "views/admin/pages/HistorialIngresos";
import VentasDirectas from "views/admin/pages/VentasDirectas";
import GestionSuscripciones from "views/admin/pages/GestionSuscripciones";
import GestionPlanesSuscripcion from "views/admin/pages/GestionPlanesSuscripcion";
import GestionCategorias from "views/admin/pages/GestionCategorias";
import GestionServiciosPorHora from "views/admin/pages/GestionServiciosPorHora";
import HabilitarFeriados from "views/admin/pages/HabilitarFeriados";
import PanelFeriadosEquipo from "views/admin/pages/PanelFeriadosEquipo";
import GestionClases from "views/admin/pages/GestionClases";
import GestionPlanesMembresia from "views/admin/pages/GestionPlanesMembresia";
import GestionMembresias from "views/admin/pages/GestionMembresias";
import ClasesDelDia from "views/admin/pages/ClasesDelDia";
import AgendarClase from "views/pages/AgendarClase";
import MisClases from "views/pages/MisClases";
import MiPlanClase from "views/pages/MiPlanClase";
import MiProgreso from "views/pages/MiProgreso";
import MiEntrenamiento from "views/pages/MiEntrenamiento";
import MiRutina from "views/pages/MiRutina";
import PlanAlimenticio from "views/pages/PlanAlimenticio";
import HistorialEntrenamiento from "views/pages/HistorialEntrenamiento";
import DiarioAlimenticio from "views/pages/DiarioAlimenticio";
import MiembrosEntrenamiento from "views/admin/pages/MiembrosEntrenamiento";
import ClasePruebaInvitado from "views/invitados/pages/ClasePruebaInvitado";
import ReservasMesaHoy from "views/admin/pages/reservasMesa/ReservasMesaHoy";
import ListadoReservasMesa from "views/admin/pages/reservasMesa/ListadoReservasMesa";
import ConfiguracionReservasMesa from "views/admin/pages/reservasMesa/ConfiguracionReservasMesa";
import BloqueosReservasMesa from "views/admin/pages/reservasMesa/BloqueosReservasMesa";

// Set de íconos del sidebar admin (mismo lenguaje visual en todos los
// ítems — antes se mezclaban Nucleo Icons y Font Awesome con trazos
// distintos). El color de cada uno se mantiene igual al que tenía antes
// (mismos hex del tema Argon: primary/success/warning/danger/yellow/
// purple), solo cambia el dibujo del ícono.
import {
  LayoutGrid,
  CalendarPlus,
  CalendarCheck,
  Users,
  User,
  IdCard,
  CreditCard,
  Layers,
  Gift,
  Tag,
  Scissors,
  Clock,
  Package,
  Building2,
} from "lucide-react";

const ICONO_COLOR = {
  primary: "#5e72e4",
  success: "#2dce89",
  warning: "#fb6340",
  danger: "#f5365c",
  yellow: "#ffd600",
  purple: "#8965e0",
};

const iconoSidebar = (Icono, color) => (
  <Icono size={16} color={ICONO_COLOR[color]} strokeWidth={2} />
);

/* =========================
   🔓 RUTAS PÚBLICAS
========================= */
export const publicRoutes = [
  { path: "/login", component: <Login />, layout: "/auth", invisible: true },
  {
    path: "/register",
    component: <Register />,
    layout: "/auth",
    invisible: true,
  },
  {
    path: "/recuperar-contrasena",
    component: <ForgotPassword />,
    layout: "/auth",
    invisible: true,
  },
  {
    path: "/reiniciar-contrasena/:token",
    component: <ReiniciarContraseña />,
    layout: "/auth",
    invisible: true,
  },
  { path: "/inicio", component: <Landing />, invisible: true },
  { path: "/reservar", component: <ReservarHoraInvitado />, invisible: true },
  {
    path: "/clase-de-prueba",
    component: <ClasePruebaInvitado />,
    invisible: true,
  },
  {
    path: "/cancelar-reserva-invitado",
    component: <CancelarInvitado />,
    invisible: true,
  },
  {
    path: "/verificar-cuenta",
    component: <VerificarCuenta />,
    invisible: true,
  },
  {
    path: "/registro-negocio",
    component: <RegistrarNegocio />,
    invisible: true,
  },
  {
    path: "/confirmar-reserva",
    component: <ConfirmacionResultado />,
    invisible: true,
  },
];

/* =========================
   👤 CLIENTE
========================= */
export const clienteRoutes = [
  {
    path: "/index",
    name: "Inicio",
    icon: "ni ni-shop text-primary",
    component: <Principal />,
    layout: "/admin",
  },
  {
    path: "/reservar-hora",
    name: "Reservar hora",
    icon: "ni ni-calendar-grid-58 text-success",
    component: <ReservarHora />,
    layout: "/admin",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },
  {
    path: "/administrar-reservas",
    name: "Mis reservas",
    icon: "ni ni-folder-17 text-info",
    component: <Administrar />,
    layout: "/admin",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },
  {
    path: "/suscripcion",
    name: "Suscripción",
    icon: "ni ni-credit-card text-warning",
    component: <Suscripcion />,
    layout: "/admin",
    excludeSlugs: ["lumicabeauty", "team-hans"],
    excludeRubros: ["gimnasio"],
  },
  {
    path: "/profesionales",
    name: "Profesionales",
    icon: "ni ni-single-02 text-primary",
    component: <BarberosPage />,
    layout: "/admin",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },
  {
    path: "/servicios",
    name: "Servicios",
    icon: "fas fa-cut text-danger",
    component: <PresentarServicios />,
    layout: "/admin",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },

  {
    path: "/catalogo-canjes",
    name: "Canjear puntos",
    icon: "ni ni-trophy text-yellow",
    component: <CatalogoCanjes />,
    layout: "/admin",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },

  /* ── Clases grupales (solo empresas tipo gimnasio con el módulo activo) ── */
  {
    path: "/agendar-clase",
    name: "Agendar clase",
    icon: "fas fa-dumbbell text-success",
    component: <AgendarClase />,
    layout: "/admin",
    requiereModulo: "clasesGrupales",
  },
  {
    path: "/mis-clases",
    name: "Mis clases",
    icon: "ni ni-folder-17 text-info",
    component: <MisClases />,
    layout: "/admin",
    requiereModulo: "clasesGrupales",
  },
  {
    path: "/mi-plan",
    name: "Mi plan",
    icon: "ni ni-credit-card text-warning",
    component: <MiPlanClase />,
    layout: "/admin",
    requiereModulo: "clasesGrupales",
  },
  {
    path: "/mi-progreso",
    name: "Mi progreso",
    icon: "fas fa-fire text-warning",
    component: <MiProgreso />,
    layout: "/admin",
    requiereModulo: "clasesGrupales",
  },
  {
    path: "/mi-entrenamiento",
    name: "Mi entrenamiento",
    icon: "fas fa-dumbbell text-primary",
    component: <MiEntrenamiento />,
    layout: "/admin",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/mi-rutina",
    name: "Mi rutina",
    icon: "fas fa-clipboard-list text-info",
    component: <MiRutina />,
    layout: "/admin",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/plan-alimenticio",
    name: "Plan alimenticio",
    icon: "fas fa-apple-alt text-success",
    component: <PlanAlimenticio />,
    layout: "/admin",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/historial-entrenamiento",
    name: "Historial",
    icon: "fas fa-history text-warning",
    component: <HistorialEntrenamiento />,
    layout: "/admin",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/diario-alimenticio",
    name: "Diario alimenticio",
    icon: "fas fa-book-open text-danger",
    component: <DiarioAlimenticio />,
    layout: "/admin",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/centro-ayuda",
    name: "Centro de ayuda",
    icon: "ni ni-support-16 text-purple",
    component: <CentroAyuda />,
    layout: "/admin",
  },
  {
    path: "/politicas",
    name: "Políticas",
    icon: "ni ni-book-bookmark text-info",
    component: <Politicas />,
    layout: "/admin",
  },
  {
    path: "/contacto",
    name: "Contacto",
    icon: "ni ni-email-83 text-info",
    component: <Contacto />,
    layout: "/admin",
  },

  // ocultas
  { path: "/perfil", component: <Perfil />, layout: "/admin", invisible: true, todosLosRubros: true },
  {
    path: "/cambiar-contrasena",
    component: <CambiarContrasena />,
    layout: "/admin",
    invisible: true,
    todosLosRubros: true,
  },
  {
    path: "/suscripcion/resultado",
    component: <SuscripcionResultado />,
    layout: "/admin",
    invisible: true,
  },
];

/* =========================
   ✂️ BARBERO / ADMIN
========================= */
export const barberoRoutes = [
  /* ── Principal ── */
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: iconoSidebar(LayoutGrid, "primary"),
    component: <AdminDashboard />,
    layout: "/admin",
    section: "principal",
  },
  {
    // Bares/restaurantes: su inicio es la vista del día de reservas de mesa
    // (el dashboard de arriba es de barbería). Ver RUBROS_MENU_PROPIO en
    // utils/filtrarRutas.js.
    path: "/dashboard",
    component: <ReservasMesaHoy />,
    layout: "/admin",
    invisible: true,
    soloRubros: ["restaurante"],
  },

  /* ── Reservas de mesa (módulo reservasMesas) ── */
  {
    path: "/reservas-mesa-menu",
    name: "Reservas de mesa",
    icon: iconoSidebar(CalendarCheck, "success"),
    layout: "/admin",
    section: "reservas",
    requiereModulo: "reservasMesas",
    children: [
      {
        path: "/reservas-mesa-hoy",
        name: "Hoy",
        icon: "fas fa-utensils text-success",
        component: <ReservasMesaHoy />,
        layout: "/admin",
        requiereModulo: "reservasMesas",
      },
      {
        path: "/reservas-mesa",
        name: "Todas las reservas",
        icon: "fas fa-list text-primary",
        component: <ListadoReservasMesa />,
        layout: "/admin",
        requiereModulo: "reservasMesas",
      },
      {
        path: "/reservas-mesa-bloqueos",
        name: "Bloqueos",
        icon: "fas fa-ban text-danger",
        component: <BloqueosReservasMesa />,
        layout: "/admin",
        soloAdmin: true,
        requiereModulo: "reservasMesas",
      },
      {
        path: "/reservas-mesa-configuracion",
        name: "Configuración",
        icon: "fas fa-cog text-info",
        component: <ConfiguracionReservasMesa />,
        layout: "/admin",
        soloAdmin: true,
        requiereModulo: "reservasMesas",
      },
    ],
  },
  {
    path: "/mi-entrenamiento",
    name: "Mi entrenamiento",
    icon: "fas fa-dumbbell text-primary",
    component: <MiEntrenamiento />,
    layout: "/admin",
    section: "principal",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/mi-rutina",
    name: "Mi rutina",
    icon: "fas fa-clipboard-list text-info",
    component: <MiRutina />,
    layout: "/admin",
    section: "principal",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/plan-alimenticio",
    name: "Plan alimenticio",
    icon: "fas fa-apple-alt text-success",
    component: <PlanAlimenticio />,
    layout: "/admin",
    section: "principal",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/historial-entrenamiento",
    name: "Historial",
    icon: "fas fa-history text-warning",
    component: <HistorialEntrenamiento />,
    layout: "/admin",
    section: "principal",
    requiereModulo: "entrenamientoPersonal",
  },
  {
    path: "/diario-alimenticio",
    name: "Diario alimenticio",
    icon: "fas fa-book-open text-danger",
    component: <DiarioAlimenticio />,
    layout: "/admin",
    section: "principal",
    requiereModulo: "entrenamientoPersonal",
  },

  /* ── Reservas ── */
  {
    path: "/reservar-hora-cliente",
    name: "Agendar cliente",
    icon: iconoSidebar(CalendarPlus, "success"),
    component: <ReservarHoraBarbero />,
    layout: "/admin",
    section: "reservas",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },
  {
    path: "/reservas",
    name: "Reservas del día",
    icon: iconoSidebar(CalendarCheck, "success"),
    component: <ReservasDiarias />,
    layout: "/admin",
    section: "reservas",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },

  /* ── Gestión ── */
  {
    path: "/gestion-clientes",
    name: "Clientes",
    icon: iconoSidebar(Users, "warning"),
    component: <GestionClientes />,
    layout: "/admin",
    section: "gestion",
    excludeSlugs: ["team-hans"],
  },
  {
    // Lista simple de miembros (dueño + amigos) para empresas de solo
    // entrenamiento personal — a propósito NO es GestionClientes (esa trae
    // reservas/suscripciones/membresías que acá no aplican). Solo admin.
    path: "/miembros-entrenamiento",
    name: "Miembros",
    icon: "fas fa-user-friends text-warning",
    component: <MiembrosEntrenamiento />,
    layout: "/admin",
    section: "gestion",
    requiereModulo: "entrenamientoPersonal",
    soloAdmin: true,
  },
  {
    path: "/gestion-profesionales",
    name: "Profesionales",
    icon: iconoSidebar(User, "primary"),
    component: <CrearBarberoCompleto />,
    layout: "/admin",
    section: "gestion",
    soloAdmin: true,
    todosLosRubros: true, // un restaurante también crea las cuentas de su equipo
    excludeSlugs: ["team-hans"],
  },
  {
    // Panel comparativo para negocios con más de un profesional: cuánto
    // genera cada uno, sus reservas, y un salto directo a la agenda de
    // cualquiera. Solo lo ve un admin (dueño/secretaria).
    path: "/equipo",
    name: "Equipo",
    icon: iconoSidebar(IdCard, "primary"),
    component: <PanelEquipo />,
    layout: "/admin",
    section: "gestion",
    soloAdmin: true,
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
  },

  {
    path: "/suscripciones",
    name: "Suscripciones",
    icon: iconoSidebar(CreditCard, "warning"),
    component: <GestionSuscripciones />,
    layout: "/admin",
    excludeSlugs: ["lumicabeauty", "don-valentino", "danails-studio", "team-hans"],
    excludeRubros: ["gimnasio"],
    section: "gestion",
  },
  {
    path: "/planes-suscripcion",
    name: "Planes de suscripción",
    icon: iconoSidebar(Layers, "warning"),
    component: <GestionPlanesSuscripcion />,
    layout: "/admin",
    excludeSlugs: ["lumicabeauty", "don-valentino", "danails-studio", "team-hans"],
    excludeRubros: ["gimnasio"],
    section: "gestion",
    soloAdmin: true,
  },

  {
    path: "/gestion-canjes",
    name: "Canjes",
    icon: iconoSidebar(Gift, "warning"),
    component: <GestionCanjes />,
    layout: "/admin",
    section: "gestion",
    excludeSlugs: ["team-hans"],
  },
  {
    path: "/gestion-categorias",
    name: "Categorías",
    icon: iconoSidebar(Tag, "yellow"),
    component: <GestionCategorias />,
    layout: "/admin",
    section: "gestion",
    soloAdmin: true,
    excludeSlugs: ["team-hans"],
  },
  {
    // submenu: Servicios
    path: "/servicios-menu",
    name: "Servicios",
    icon: iconoSidebar(Scissors, "danger"),
    layout: "/admin",
    section: "gestion",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
    children: [
      {
        path: "/gestion-servicios",
        name: "Catálogo",
        icon: "fas fa-list text-danger",
        component: <GestionServicios />,
        layout: "/admin",
        soloAdmin: true,
      },
      {
        path: "/codigos-descuento",
        name: "Códigos de descuento",
        icon: "fas fa-tags text-success",
        component: <GestionCodigosDescuento />,
        layout: "/admin",
        soloAdmin: true,
      },
      {
        path: "/asignar-servicios",
        name: "Asignar servicios",
        icon: "ni ni-settings text-info",
        component: <AsignarServiciosBarberos />,
        layout: "/admin",
      },
      {
        path: "/gestion-servicios-horas",
        name: "Restringir horarios servicios",
        icon: "fas fa-clock text-warning",
        component: <GestionServiciosPorHora />,
        layout: "/admin",
      },
    ],
  },
  {
    // submenu: Horarios
    path: "/horarios-menu",
    name: "Horarios",
    icon: iconoSidebar(Clock, "danger"),
    layout: "/admin",
    section: "gestion",
    excludeSlugs: ["team-hans"],
    excludeRubros: ["gimnasio"],
    children: [
      {
        path: "/asignar-horas",
        name: "Asignar horarios",
        icon: "fas fa-user-clock text-primary",
        component: <WizardBarberoSemana />,
        layout: "/admin",
      },
      {
        path: "/gestion-horarios",
        name: "Administrar horarios",
        icon: "fas fa-clock text-danger",
        component: <GestionHorariosBarbero />,
        layout: "/admin",
      },
      {
        // Auto-toggle individual, ahora oculto del menú: con el
        // interruptor maestro por empresa en "Feriados del equipo", si un
        // profesional se marca acá pero el admin no habilitó el feriado a
        // nivel empresa, queda sin efecto y sin aviso — confuso. La ruta
        // se deja registrada (invisible, no eliminada) por si alguien
        // todavía la tiene como acceso directo guardado.
        path: "/gestion-feriados",
        name: "Administrar Feriados",
        icon: "fas fa-clock text-success",
        component: <HabilitarFeriados />,
        layout: "/admin",
        invisible: true,
      },
      {
        // Vista de equipo del feriado: quién trabaja, con qué horario,
        // qué servicios y a qué precio. Solo admin — HabilitarFeriados de
        // arriba sigue siendo el auto-toggle simple para cualquier
        // profesional, sin tocar.
        path: "/gestion-feriados-equipo",
        name: "Feriados del equipo",
        icon: "fas fa-calendar-check text-success",
        component: <PanelFeriadosEquipo />,
        layout: "/admin",
        soloAdmin: true,
        excludeRubros: ["gimnasio"],
      },

      {
        path: "/gestion-vacaciones",
        name: "Vacaciones",
        icon: "fas fa-umbrella-beach text-success",
        component: <GestionVacaciones />,
        layout: "/admin",
      },
    ],
  },

  {
    // submenu: Productos
    path: "/productos-menu",
    name: "Productos",
    icon: iconoSidebar(Package, "primary"),
    layout: "/admin",
    section: "gestion",
    excludeSlugs: ["team-hans"],
    children: [
      {
        path: "/gestion-productos",
        name: "Catálogo",
        icon: "ni ni-bullet-list-67 text-primary",
        component: <GestionProductos />,
        layout: "/admin",
      },
      {
        path: "/ventas-directas",
        name: "Ventas directas",
        icon: "ni ni-bag-17 text-success",
        component: <VentasDirectas />,
        layout: "/admin",
      },
      {
        path: "/estadisticas-productos",
        name: "Estadísticas",
        icon: "ni ni-chart-bar-32 text-primary",
        component: <EstadisticasProductos />,
        layout: "/admin",
      },
    ],
  },

  {
    // submenu: Clases (solo para empresas tipo gimnasio con el módulo activado)
    path: "/clases-menu",
    name: "Clases",
    icon: "fas fa-dumbbell text-danger",
    layout: "/admin",
    section: "gestion",
    requiereModulo: "clasesGrupales",
    children: [
      {
        path: "/clases-del-dia",
        name: "Clases del día",
        icon: "fas fa-calendar-day text-success",
        component: <ClasesDelDia />,
        layout: "/admin",
        requiereModulo: "clasesGrupales",
      },
      {
        path: "/gestion-clases",
        name: "Clases y horarios",
        icon: "fas fa-calendar-alt text-danger",
        component: <GestionClases />,
        layout: "/admin",
        soloAdmin: true,
        requiereModulo: "clasesGrupales",
      },
      {
        path: "/planes-membresia",
        name: "Planes",
        icon: "ni ni-collection text-primary",
        component: <GestionPlanesMembresia />,
        layout: "/admin",
        soloAdmin: true,
        requiereModulo: "clasesGrupales",
      },
      {
        path: "/membresias",
        name: "Membresías",
        icon: "ni ni-credit-card text-warning",
        component: <GestionMembresias />,
        layout: "/admin",
        soloAdmin: true,
        requiereModulo: "clasesGrupales",
      },
    ],
  },

  /* ── Otros ── */
  {
    // submenu: Empresa
    path: "/empresa-menu",
    name: "Empresa",
    icon: iconoSidebar(Building2, "purple"),
    layout: "/admin",
    section: "otros",
    soloAdmin: true,
    todosLosRubros: true,
    children: [
      {
        path: "/configuracion-empresa",
        name: "Configuración",
        icon: "ni ni-settings text-purple",
        component: <ConfiguracionEmpresa />,
        layout: "/admin",
        todosLosRubros: true,
      },
      {
        // Panel de estadísticas de barbería/salón (reservas + suscripciones):
        // no aplica al modelo de gimnasio (membresías + clases), por eso se
        // excluye ahí y se reemplaza por la entrada de abajo.
        path: "/estadisticas",
        name: "Estadísticas",
        icon: "fas fa-chart-line text-info",
        component: <Estadisticas />,
        layout: "/admin",
        excludeSlugs: ["team-hans"],
        excludeRubros: ["gimnasio"],
      },
      {
        // Reportes de rentabilidad por servicio (ingreso/volumen líder y
        // rezagado, tendencia, evolución mensual, y cruce por profesional
        // para el admin) — página aparte del dashboard principal. La ve
        // cualquier profesional (ve lo suyo) y el admin (ve todo).
        path: "/estadisticas-servicios",
        name: "Servicios",
        icon: "fas fa-chart-pie text-info",
        component: <EstadisticasServicios />,
        layout: "/admin",
        excludeSlugs: ["team-hans"],
        excludeRubros: ["gimnasio"],
      },
      {
        // Panel de estadísticas para gimnasios/boxes (membresías + clases
        // grupales) — mismo nombre/posición de menú, pero solo visible
        // para empresas con el módulo de clases grupales activo.
        path: "/estadisticas-gimnasio",
        name: "Estadísticas",
        icon: "fas fa-chart-line text-info",
        component: <EstadisticasGimnasio />,
        layout: "/admin",
        requiereModulo: "clasesGrupales",
      },
      {
        path: "/HistorialIngresos",
        name: "Historial Ingresos",
        icon: "fas fa-chart-line text-success",
        component: <HistorialIngresos />,
        layout: "/admin",
        excludeSlugs: ["team-hans"],
      },
    ],
  },

  // ocultas (el link ya existe en AdminNavbar/Sidebar, pero faltaba la
  // ruta acá, por eso el admin caía siempre al dashboard)
  { path: "/perfil", component: <Perfil />, layout: "/admin", invisible: true, todosLosRubros: true },
  {
    path: "/cambiar-contrasena",
    component: <CambiarContrasena />,
    layout: "/admin",
    invisible: true,
    todosLosRubros: true,
  },
];
