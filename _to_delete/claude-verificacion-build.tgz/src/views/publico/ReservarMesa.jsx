import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Button, Card, CardBody, Col, Container, FormGroup, Input, Label, Row, Spinner } from "reactstrap";
import { CalendarCheck, Phone } from "lucide-react";
import { useEmpresa } from "context/EmpresaContext";
import { construirTema } from "utils/temaEmpresa";
import SelectorHoraSector from "components/reservasMesa/SelectorHoraSector";
import {
  getInfoReservaMesaPublica,
  getDisponibilidadMesaPublica,
  postReservaMesaPublica,
} from "api/reservasMesa";
import { DIAS_SEMANA, fechaLarga, nuevaClave, telLink } from "utils/reservasMesa";

const diaDe = (fecha) => {
  const [y, m, d] = fecha.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12)).getUTCDay();
};

const Paso = ({ n, titulo, color, children }) => (
  <div className="mb-4">
    <div className="d-flex align-items-center mb-2" style={{ gap: 10 }}>
      <span
        className="d-inline-flex align-items-center justify-content-center rounded-circle text-white"
        style={{ width: 26, height: 26, background: color, fontSize: 13, fontWeight: 700, flexShrink: 0 }}
      >
        {n}
      </span>
      <strong>{titulo}</strong>
    </div>
    {children}
  </div>
);

/** Página pública para reservar mesa, sin crear cuenta. */
const ReservarMesa = () => {
  const { slug } = useParams();
  const { empresa } = useEmpresa();
  const theme = construirTema(empresa?.colores);

  const [info, setInfo] = useState(null);
  const [cargandoInfo, setCargandoInfo] = useState(true);
  const [noDisponible, setNoDisponible] = useState(false);

  const [personas, setPersonas] = useState("");
  const [fecha, setFecha] = useState("");
  const [disp, setDisp] = useState({ horas: [], cargando: false, grupoGrande: false, cerrado: false });
  const [eleccion, setEleccion] = useState({ hora: "", sectorId: "" });
  const [datos, setDatos] = useState({ nombre: "", telefono: "", email: "", comentarios: "", sitioWeb: "" });
  const [cumple, setCumple] = useState({ es: false, festejado: "", detalle: "" });
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");
  const [alternativas, setAlternativas] = useState([]);
  const [confirmada, setConfirmada] = useState(null);
  const [clave] = useState(nuevaClave);
  const [recarga, setRecarga] = useState(0);

  useEffect(() => {
    let vigente = true;
    getInfoReservaMesaPublica(slug)
      .then(({ data }) => {
        if (!vigente) return;
        setInfo(data);
        setNoDisponible(!data.activa);
      })
      .catch(() => vigente && setNoDisponible(true))
      .finally(() => vigente && setCargandoInfo(false));
    return () => {
      vigente = false;
    };
  }, [slug]);

  const n = Number(personas);
  const diaCerrado = useMemo(
    () => !!(fecha && info?.diasAbiertos && !info.diasAbiertos.includes(diaDe(fecha))),
    [fecha, info],
  );

  // Cambiar fecha o personas reinicia la elección
  useEffect(() => {
    setEleccion({ hora: "", sectorId: "" });
    setAlternativas([]);
    setError("");
  }, [fecha, n]);

  // Horas disponibles (también se recarga si alguien tomó el lugar recién)
  useEffect(() => {
    if (!fecha || !(n >= 1) || diaCerrado) {
      setDisp({ horas: [], cargando: false, grupoGrande: false, cerrado: diaCerrado });
      return;
    }
    let vigente = true;
    setDisp((d) => ({ ...d, cargando: true }));
    getDisponibilidadMesaPublica(slug, { fecha, personas: n })
      .then(({ data }) => {
        if (vigente) setDisp({ horas: data.horas || [], cargando: false, grupoGrande: !!data.grupoGrande, cerrado: !!data.cerrado });
      })
      .catch(() => vigente && setDisp({ horas: [], cargando: false, grupoGrande: false, cerrado: false }));
    return () => {
      vigente = false;
    };
  }, [slug, fecha, n, diaCerrado, recarga]);

  const setDato = (campo, valor) => setDatos((d) => ({ ...d, [campo]: valor }));

  const listo =
    eleccion.hora && eleccion.sectorId && datos.nombre.trim().length >= 2 && datos.telefono.trim() && datos.email.trim();

  const reservar = async () => {
    setEnviando(true);
    setError("");
    setAlternativas([]);
    try {
      const { data } = await postReservaMesaPublica(slug, {
        fecha,
        hora: eleccion.hora,
        personas: n,
        sectorId: eleccion.sectorId,
        nombre: datos.nombre,
        telefono: datos.telefono,
        email: datos.email,
        comentarios: datos.comentarios,
        cumpleanos: cumple,
        claveIdempotencia: clave,
        sitioWeb: datos.sitioWeb,
      });
      setConfirmada(data);
      window.scrollTo(0, 0);
    } catch (e) {
      const d = e?.response?.data || {};
      setError(d.message || "No pudimos completar la reserva. Intenta de nuevo.");
      setAlternativas(d.alternativas || []);
      if (d.code === "SIN_CUPO") setRecarga((x) => x + 1);
    } finally {
      setEnviando(false);
    }
  };

  const nombreLocal = info?.empresa?.nombre || empresa?.nombre || "";
  const telefono = info?.empresa?.telefono || empresa?.telefono || "";

  const contenedor = (contenido) => (
    <div style={{ minHeight: "100vh", background: theme.softBg || "#f6f9fc" }}>
      <div style={{ background: theme.heroBg, color: "#fff" }} className="py-5">
        <Container className="text-center">
          <CalendarCheck size={32} />
          <h1 className="h2 text-white mt-2 mb-1">Reserva tu mesa</h1>
          <div style={{ opacity: 0.85 }}>{nombreLocal}</div>
        </Container>
      </div>
      <Container style={{ maxWidth: 720, marginTop: -32 }} className="pb-5">
        <Card className="shadow border-0">
          <CardBody className="p-4">{contenido}</CardBody>
        </Card>
        <div className="text-center mt-3">
          <Link to={`/${slug}`} style={{ color: theme.textMuted }}>
            Volver a {nombreLocal || "inicio"}
          </Link>
        </div>
      </Container>
    </div>
  );

  if (cargandoInfo) {
    return contenedor(
      <div className="text-center py-4">
        <Spinner style={{ color: theme.primary }} />
      </div>,
    );
  }

  if (noDisponible) {
    return contenedor(
      <div className="text-center py-3">
        <p className="mb-3">Por ahora no se puede reservar en línea.</p>
        {telefono && (
          <a href={telLink(telefono)} className="btn" style={{ background: theme.primary, color: "#fff" }}>
            <Phone size={16} style={{ verticalAlign: "-3px" }} /> Llamar al {telefono}
          </a>
        )}
      </div>,
    );
  }

  if (confirmada) {
    const pendiente = confirmada.estado === "pendiente";
    return contenedor(
      <div className="text-center py-2">
        <div style={{ fontSize: 48 }}>{pendiente ? "📩" : "✅"}</div>
        <h2 className="h3">{pendiente ? "¡Solicitud recibida!" : "¡Reserva confirmada!"}</h2>
        <p className="text-muted">
          {pendiente
            ? "El local la revisará y te avisaremos por correo cuando quede confirmada."
            : "Te enviamos la confirmación por correo."}
        </p>
        <div className="border rounded p-3 text-left mx-auto" style={{ maxWidth: 380 }}>
          <div>
            <strong>Código:</strong> <span style={{ letterSpacing: 1 }}>{confirmada.codigo}</span>
          </div>
          <div className="text-capitalize">
            <strong>Fecha:</strong> {fechaLarga(confirmada.fecha)}
          </div>
          <div>
            <strong>Hora:</strong> {confirmada.hora}
          </div>
          <div>
            <strong>Personas:</strong> {confirmada.personas}
          </div>
          <div>
            <strong>Sector:</strong> {confirmada.sector}
          </div>
        </div>
        {info?.toleranciaMinutos > 0 && !pendiente && (
          <p className="small text-muted mt-3">
            Guardamos tu lugar hasta {info.toleranciaMinutos} minutos después de la hora.
          </p>
        )}
      </div>,
    );
  }

  return contenedor(
    <>
      {info?.mensajePublico && (
        <div className="alert mb-4" style={{ background: theme.primaryLight, color: theme.textDark }}>
          {info.mensajePublico}
        </div>
      )}

      <Paso n={1} titulo="¿Cuántos son y qué día?" color={theme.primary}>
        <Row>
          <Col xs="5">
            <Input
              type="number"
              min="1"
              placeholder="Personas"
              value={personas}
              onChange={(e) => setPersonas(e.target.value)}
            />
          </Col>
          <Col xs="7">
            <Input type="date" min={info?.hoy} max={info?.hasta} value={fecha} onChange={(e) => setFecha(e.target.value)} />
          </Col>
        </Row>
        {info?.diasAbiertos && (
          <small className="text-muted d-block mt-1">
            Recibimos reservas los {info.diasAbiertos.map((d) => DIAS_SEMANA[d].toLowerCase()).join(", ")}.
          </small>
        )}
      </Paso>

      {fecha && n >= 1 && (
        <Paso n={2} titulo="Elige hora y sector" color={theme.primary}>
          {disp.cargando ? (
            <Spinner size="sm" style={{ color: theme.primary }} />
          ) : disp.grupoGrande || n > (info?.maxPersonas || Infinity) ? (
            <div className="alert alert-light border">
              Para grupos de más de {info?.maxPersonas} personas, contáctanos directamente
              {telefono ? (
                <>
                  : <a href={telLink(telefono)}>{telefono}</a>
                </>
              ) : (
                "."
              )}
            </div>
          ) : disp.cerrado || diaCerrado ? (
            <p className="text-muted mb-0">Ese día no recibimos reservas. Prueba otra fecha.</p>
          ) : disp.horas.length === 0 ? (
            <p className="text-muted mb-0">No quedan horas disponibles para ese día y ese grupo. Prueba otra fecha.</p>
          ) : (
            <SelectorHoraSector
              horas={disp.horas}
              valor={eleccion}
              onChange={setEleccion}
              colorPrimario={theme.primary}
            />
          )}
        </Paso>
      )}

      {eleccion.hora && (
        <Paso n={3} titulo="Tus datos" color={theme.primary}>
          <Row>
            <Col md="6">
              <FormGroup>
                <Label>Nombre</Label>
                <Input value={datos.nombre} maxLength={80} autoComplete="name" onChange={(e) => setDato("nombre", e.target.value)} />
              </FormGroup>
            </Col>
            <Col md="6">
              <FormGroup>
                <Label>Teléfono</Label>
                <Input type="tel" value={datos.telefono} maxLength={25} autoComplete="tel" placeholder="+56 9 ..." onChange={(e) => setDato("telefono", e.target.value)} />
              </FormGroup>
            </Col>
            <Col md="12">
              <FormGroup>
                <Label>Correo</Label>
                <Input type="email" value={datos.email} maxLength={120} autoComplete="email" onChange={(e) => setDato("email", e.target.value)} />
                <small className="text-muted">Te enviaremos la confirmación aquí.</small>
              </FormGroup>
            </Col>
          </Row>

          <div className="custom-control custom-checkbox mb-2">
            <input id="pub-cumple" type="checkbox" className="custom-control-input" checked={cumple.es} onChange={(e) => setCumple((c) => ({ ...c, es: e.target.checked }))} />
            <label className="custom-control-label" htmlFor="pub-cumple">
              Vamos a celebrar un cumpleaños 🎂
            </label>
          </div>
          {cumple.es && (
            <>
              {info?.mensajeCumpleanos && <div className="small text-muted mb-2">{info.mensajeCumpleanos}</div>}
              <Row>
                <Col md="5">
                  <FormGroup>
                    <Label>¿De quién?</Label>
                    <Input value={cumple.festejado} maxLength={80} onChange={(e) => setCumple((c) => ({ ...c, festejado: e.target.value }))} />
                  </FormGroup>
                </Col>
                <Col md="7">
                  <FormGroup>
                    <Label>Algo que debamos saber (opcional)</Label>
                    <Input value={cumple.detalle} maxLength={300} onChange={(e) => setCumple((c) => ({ ...c, detalle: e.target.value }))} />
                  </FormGroup>
                </Col>
              </Row>
            </>
          )}

          <FormGroup>
            <Label>Comentarios (opcional)</Label>
            <Input type="textarea" rows="2" maxLength={500} value={datos.comentarios} placeholder="Silla de bebé, accesibilidad..." onChange={(e) => setDato("comentarios", e.target.value)} />
          </FormGroup>

          {/* Campo trampa para bots: invisible para personas */}
          <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", width: 1, height: 1, overflow: "hidden" }}>
            <label htmlFor="sitioWeb">No llenar</label>
            <input id="sitioWeb" tabIndex={-1} autoComplete="off" value={datos.sitioWeb} onChange={(e) => setDato("sitioWeb", e.target.value)} />
          </div>

          {error && (
            <div className="alert alert-warning">
              {error}
              {alternativas.length > 0 && (
                <div className="mt-2">
                  Con lugar:{" "}
                  {alternativas.map((a) => (
                    <Button
                      key={`${a.hora}-${a.sectorId}`}
                      size="sm"
                      color="light"
                      className="m-1"
                      onClick={() => setEleccion({ hora: a.hora, sectorId: a.sectorId })}
                    >
                      {a.hora} · {a.sector}
                    </Button>
                  ))}
                </div>
              )}
            </div>
          )}

          <Button
            block
            size="lg"
            disabled={!listo || enviando}
            onClick={reservar}
            style={{ background: theme.primary, borderColor: theme.primary, color: "#fff" }}
          >
            {enviando ? "Reservando..." : info?.confirmacionAutomatica ? "Confirmar reserva" : "Enviar solicitud"}
          </Button>
          {info?.cancelacion?.permitida && (
            <small className="text-muted d-block text-center mt-2">
              Podrás cancelar desde el link del correo hasta {info.cancelacion.horasLimite} hora(s) antes.
            </small>
          )}
        </Paso>
      )}
    </>,
  );
};

export default ReservarMesa;
