import React, { useState, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Button,
  Card,
  CardBody,
  Badge,
  Navbar,
  Nav,
  NavItem,
  NavLink,
  Form,
  FormGroup,
  Input,
} from "reactstrap";
import { Link } from "react-router-dom";

// Iconos
import {
  FiCalendar,
  FiCheckCircle,
  FiArrowRight,
  FiInstagram,
  FiSmartphone,
  FiZap,
  FiClock,
  FiMail,
  FiGift,
  FiUsers,
  FiBell,
  FiRefreshCw,
  FiTrendingUp,
  FiMessageCircle,
  FiUserCheck,
  FiUserX,
  FiShield,
  FiStar,
} from "react-icons/fi";
import { FaWhatsapp } from "react-icons/fa";
import NegociosConfianza from "./NegociosConfianza";
import FuncionalidadesSection from "components/Principal/FuncionalidadesSection";

const LandingPage = () => {
  const [scrolled, setScrolled] = useState(false);
  const [testimoniosActivos, setTestimoniosActivos] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const WHATSAPP_NUMBER = "56975297584";
  const MESSAGE = encodeURIComponent(
    "Hola, estoy interesado en probar la agenda para mi negocio",
  );

  const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${MESSAGE}`;

  const MESSAGE_PLAN_NEGOCIO = encodeURIComponent(
    "Hola, tengo un negocio con 6 o más profesionales (o varias sucursales) y quiero cotizar el Plan Negocio",
  );
  const WHATSAPP_URL_PLAN_NEGOCIO = `https://wa.me/${WHATSAPP_NUMBER}?text=${MESSAGE_PLAN_NEGOCIO}`;

  // Cliente real
  const clienteReal = {
    _id: "698de476677550fcd3d2209c",
    nombre: "La Santa Barbería",
    tipo: "barbería",
    imagen:
      "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&q=80&w=500",
    rating: "5.0",
    testimonio:
      "Antes me llegaban decenas de WhatsApp y llamadas todos los días. Perdía mucho tiempo respondiendo y agendando a mano, incluso en la noche. Con AgendaFonfach, la mayoría de las reservas se hacen solas y hoy casi no tengo que contestar mensajes.",
    dueño: "Ale Robledo",
    años: 15,
    profesionales: 1,
    reservasMes: 180,
  };

  // Características de TU AGENDA (lo que vendes)
  const features = [
    {
      icon: FiZap,
      title: "Cero tiempo perdido",
      desc: "Olvídate del WhatsApp y las llamadas. Todo se gestiona automático.",
      color: "#4361ee",
      detalle: "Recupera hasta 15 horas a la semana",
      stats: "+40% productividad",
    },
    {
      icon: FiUsers,
      title: "Clientes que vuelven",
      desc: "Sistema de puntos y beneficios que fideliza como ningún otro.",
      color: "#f72585",
      detalle: "Aumenta la lealtad de tus clientes",
      stats: "+60% recompra",
    },
    {
      icon: FiBell,
      title: "Notificaciones inteligentes",
      desc: "Te avisamos cuando se libera un horario que te interesa.",
      color: "#06d6a0",
      detalle: "Nunca más pierdas una hora",
      stats: "0 horas vacías",
    },
    {
      icon: FiRefreshCw,
      title: "Lista de espera automática",
      desc: "Si alguien cancela, notificamos al próximo en la lista.",
      color: "#ff9e00",
      detalle: "Tus horas siempre ocupadas",
      stats: "100% ocupación",
    },
    {
      icon: FiTrendingUp,
      title: "Recordatorio inteligente",
      desc: "Sabemos cuándo tu cliente necesita volver y le avisamos.",
      color: "#7209b7",
      detalle: "Basado en su historial de reservas",
      stats: "+35% visitas",
    },
    {
      icon: FiGift,
      title: "Programa de puntos",
      desc: "Acumulan por cada visita y canjean por premios. Tú eliges qué dar.",
      color: "#2ec4b6",
      detalle: "Incrementa la frecuencia de visitas",
      stats: "2x frecuencia",
    },
  ];

  // Funcionalidades para profesionales
  const adminFeatures = [
    {
      icon: FiUserCheck,
      title: "Gestión completa",
      desc: "Administra usuarios, profesionales, horarios y canjes desde un panel intuitivo.",
      color: "#4361ee",
    },
    {
      icon: FiMessageCircle,
      title: "Notificaciones multicanal",
      desc: "WhatsApp, correo y notificaciones push. Todo automático.",
      color: "#f72585",
    },
    {
      icon: FiUserX,
      title: "Reserva como invitado o registrado",
      desc: "Máxima flexibilidad: sin registro para los rápidos, con beneficios para los fieles.",
      color: "#06d6a0",
    },
  ];

  // Negocios que pueden usar la agenda
  const rubros = [
    { nombre: "Barberías", icon: "💈", count: 1 },
    { nombre: "Peluquerías", icon: "💇‍♀️", count: 0 },
    { nombre: "Centros de estética", icon: "✨", count: 0 },
    { nombre: "Spa", icon: "🧖‍♀️", count: 0 },
    { nombre: "Masajes", icon: "💆‍♂️", count: 0 },
    { nombre: "Tatuajes", icon: "🖋️", count: 0 },
    { nombre: "Consultorios", icon: "🏥", count: 0 },
    { nombre: "Clínicas dentales", icon: "🦷", count: 0 },
  ];

  // PLANES
  const planes = [
    {
      nombre: "Plan Solo",
      subtitulo: "1 profesional",
      precio: "29.990",
      periodo: "mes",
      destacado: false,
      cta: "Comenzar ahora",
      accion: () => (window.location.href = "/registro-negocio"),
      incluye: [
        "Reservas ilimitadas",
        "Sistema de puntos y canjes",
        "Lista de espera automática",
        "Recordatorios inteligentes de reposición",
        "Notificaciones por email",
        "Panel de administración completo",
        "Reserva como invitado o registrado",
        "Sin comisiones por reserva",
      ],
    },
    {
      nombre: "Plan Equipo",
      subtitulo: "1 a 3 profesionales",
      precio: "44.990",
      periodo: "mes",
      destacado: true,
      badge: "Más elegido",
      cta: "Comenzar ahora",
      accion: () => (window.location.href = "/registro-negocio"),
      incluye: [
        "Todo lo del Plan Solo",
        "Hasta 3 profesionales",
        "Notificaciones por WhatsApp (cliente y profesional)",
        "Suscripciones y membresías para tus clientes",
        "Recordatorios por WhatsApp + email",
      ],
    },
    {
      nombre: "Plan Negocio",
      subtitulo: "3+ profesionales ",
      precio: null,
      periodo: null,
      destacado: false,
      cta: "Conversemos por WhatsApp",
      accion: () => window.open(WHATSAPP_URL_PLAN_NEGOCIO, "_blank"),
      incluye: [
        "Todo lo del Plan Equipo",
        "Profesionales ilimitados",
        "WhatsApp sin límite de conversaciones",
        "Múltiples sucursales",
        "Estadísticas avanzadas",
        "Soporte prioritario",
      ],
    },
  ];

  return (
    <div style={{ backgroundColor: "#ffffff" }}>
      {/* Navbar */}
      <Navbar
        className={`fixed-top ${scrolled ? "bg-white shadow-sm py-2" : "bg-transparent py-3"}`}
        expand="md"
        style={{ transition: "all 0.3s ease" }}
      >
        <Container>
          <Link
            to="/"
            className="navbar-brand d-flex align-items-center font-weight-bold"
            style={{ color: "#1a1a1a", fontSize: "1.4rem" }}
          >
            <FiCalendar className="mr-2" style={{ color: "#f72585" }} />
            <span>
              Agenda<span style={{ color: "#4361ee" }}>Fonfach</span>
            </span>
          </Link>
          <Nav className="ml-auto align-items-center" navbar>
            <NavItem className="d-none d-md-block">
              <NavLink href="#funcionalidades" className="text-dark mr-4">
                ¿Qué hace?
              </NavLink>
            </NavItem>
            <NavItem className="d-none d-md-block">
              <NavLink href="#testimonios" className="text-dark mr-4">
                Resultados reales
              </NavLink>
            </NavItem>
            <NavItem className="d-none d-md-block">
              <NavLink href="#plan-contacto" className="text-dark mr-4">
                Planes y Contacto
              </NavLink>
            </NavItem>
            <NavItem>
              <Button
                pill
                className="px-4 d-flex align-items-center gap-2"
                style={{
                  borderRadius: "50px",
                  fontWeight: "600",
                  background: "#25D366",
                  border: "none",
                  color: "white",
                }}
                onClick={() => window.open(WHATSAPP_URL, "_blank")}
              >
                <FaWhatsapp size={20} />
                Quiero probarlo
              </Button>
            </NavItem>
          </Nav>
        </Container>
      </Navbar>

      {/* Hero Section - Más enfocado en beneficios */}
      <section
        className="pt-9 pb-5"
        style={{
          background: "linear-gradient(180deg, #f8faff 0%, #ffffff 100%)",
          paddingTop: "150px",
        }}
      >
        <Container>
          <Row className="align-items-center">
            <Col lg="6" className="text-center text-lg-left mb-5">
              <Badge
                className="mb-3 px-3 py-2"
                style={{
                  background:
                    "linear-gradient(135deg, #4361ee 0%, #f72585 100%)",
                  color: "white",
                  borderRadius: "50px",
                  border: "none",
                }}
              >
                ⚡ Lanzamiento - Precio especial
              </Badge>

              <h1 className="display-3 font-weight-bold mb-4">
                Automatiza tus reservas y{" "}
                <span style={{ color: "#f72585" }}>recupera tu tiempo</span>
              </h1>

              <p
                className="lead text-muted mb-5"
                style={{ fontSize: "1.2rem" }}
              >
                Dile adiós al WhatsApp, las llamadas y los "te confirmo
                después". AgendaFonfach automatiza tus reservas, fideliza
                clientes y llena tus horas muertas.
              </p>

              {/* Stats rápidas */}
              <Row className="mb-5">
                <Col xs={4} className="text-center">
                  <h3
                    className="font-weight-bold mb-0"
                    style={{ color: "#4361ee" }}
                  >
                    15h
                  </h3>
                  <small className="text-muted">semanales recuperadas</small>
                </Col>
                <Col xs={4} className="text-center">
                  <h3
                    className="font-weight-bold mb-0"
                    style={{ color: "#f72585" }}
                  >
                    +40%
                  </h3>
                  <small className="text-muted">más reservas</small>
                </Col>
                <Col xs={4} className="text-center">
                  <h3
                    className="font-weight-bold mb-0"
                    style={{ color: "#06d6a0" }}
                  >
                    0%
                  </h3>
                  <small className="text-muted">comisión por reserva</small>
                </Col>
              </Row>

              <div className="d-flex justify-content-center justify-content-lg-start">
                <Button
                  size="lg"
                  className="mr-3 px-4 py-3 shadow-lg text-white"
                  style={{
                    background: "#4361ee",
                    border: "none",
                    borderRadius: "12px",
                  }}
                  onClick={() => (window.location.href = "/registro-negocio")}
                >
                  Comenzar ahora <FiArrowRight className="ml-2" />
                </Button>
                <Button
                  size="lg"
                  outline
                  className="px-4 py-3"
                  style={{
                    borderRadius: "12px",
                    borderColor: "#4361ee",
                    color: "#4361ee",
                  }}
                  onClick={() =>
                    document
                      .getElementById("funcionalidades")
                      .scrollIntoView({ behavior: "smooth" })
                  }
                >
                  Ver cómo funciona
                </Button>
              </div>
            </Col>
            <Col lg="6" className="position-relative">
              {/* Mockup del propio sistema de reservas en vez de una foto
                  de stock genérica — vende mejor porque muestra
                  exactamente lo que el negocio recibe: link de reserva,
                  horarios y confirmación automática. */}
              <div className="hero-mockup-wrap">
                <div className="hero-mockup-card">
                  <div className="mockup-topbar">
                    <span
                      className="mockup-dot"
                      style={{ background: "#ff5f56" }}
                    />
                    <span
                      className="mockup-dot"
                      style={{ background: "#ffbd2e" }}
                    />
                    <span
                      className="mockup-dot"
                      style={{ background: "#27c93f" }}
                    />
                    <span className="mockup-url">
                      agendafonfach.cl/tu-negocio
                    </span>
                  </div>

                  <div className="mockup-body">
                    <div className="mockup-header-row">
                      <div className="mockup-avatar">💈</div>
                      <div>
                        <div className="mockup-biz-name">
                          La Santa Barbería
                        </div>
                        <div className="mockup-biz-sub">Elige día y hora</div>
                      </div>
                    </div>

                    <div className="mockup-days-row">
                      {["Lun", "Mar", "Mié", "Jue", "Vie"].map((d, i) => (
                        <span
                          key={d}
                          className={`mockup-day-pill ${
                            i === 2 ? "active" : ""
                          }`}
                        >
                          {d}
                        </span>
                      ))}
                    </div>

                    <div className="mockup-slots-grid">
                      {["10:00", "11:30", "15:00", "16:30", "17:00", "18:30"].map(
                        (h, i) => (
                          <span
                            key={h}
                            className={`mockup-slot ${
                              i === 3 ? "selected" : ""
                            }`}
                          >
                            {i === 3 && (
                              <FiCheckCircle size={12} className="mr-1" />
                            )}
                            {h}
                          </span>
                        ),
                      )}
                    </div>

                    <div className="mockup-cta">
                      Confirmar reserva <FiArrowRight className="ml-1" />
                    </div>
                  </div>
                </div>

                <div className="floating-badge floating-whatsapp">
                  <FaWhatsapp size={16} style={{ color: "#25d366" }} />
                  <span>Recordatorio enviado ✅</span>
                </div>

                <div className="floating-badge floating-stat">
                  <FiTrendingUp size={16} style={{ color: "#06d6a0" }} />
                  <span>+40% más reservas</span>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Sección: Así de simple - Cómo funciona */}
      <section className="py-6" style={{ background: "#f8faff" }}>
        <Container>
          <div className="text-center mb-5">
            <Badge
              className="mb-3 px-3 py-2"
              style={{
                background: "#e8edff",
                color: "#4361ee",
                borderRadius: "50px",
              }}
            >
              ⚡ Simple y rápido
            </Badge>
            <h2 className="display-4 font-weight-bold">Así de simple</h2>
            <p className="text-muted">
              En menos de 10 minutos tu negocio ya está recibiendo reservas solo
            </p>
          </div>

          <Row className="align-items-start justify-content-center">
            {/* Paso 1 */}
            <Col md="3">
              <div
                className="text-center p-4 position-relative"
                style={{
                  background: "#fff",
                  borderRadius: "20px",
                  border: "1px solid rgba(67,97,238,0.1)",
                }}
              >
                <div
                  className="d-flex align-items-center justify-content-center mx-auto"
                  style={{
                    position: "absolute",
                    top: "-16px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "32px",
                    height: "32px",
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, #4361ee, #f72585)",
                    color: "white",
                    fontSize: "13px",
                    fontWeight: "600",
                  }}
                >
                  1
                </div>
                <div
                  className="d-flex align-items-center justify-content-center mx-auto mb-3"
                  style={{
                    width: "64px",
                    height: "64px",
                    borderRadius: "18px",
                    background: "#eef1ff",
                  }}
                >
                  <svg
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#4361ee"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="3" y="3" width="18" height="18" rx="4" />
                    <path d="M8 12h8M12 8v8" />
                  </svg>
                </div>
                <h5 className="font-weight-bold mb-2">Creas tu negocio</h5>
                <p className="text-muted small mb-3">
                  Registras tu negocio, tus profesionales y los horarios
                  disponibles. Sin complicaciones.
                </p>
                <span
                  className="px-3 py-1"
                  style={{
                    background: "#eef1ff",
                    color: "#4361ee",
                    borderRadius: "50px",
                    fontSize: "11px",
                    fontWeight: "600",
                  }}
                >
                  5 minutos
                </span>
              </div>
            </Col>

            {/* Flecha 1 */}
            <Col
              md="1"
              className="d-none d-md-flex align-items-center justify-content-center"
              style={{ paddingTop: "52px" }}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#c7d0f8"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </Col>

            {/* Paso 2 */}
            <Col md="3">
              <div
                className="text-center p-4 position-relative"
                style={{
                  background: "#fff",
                  borderRadius: "20px",
                  border: "1px solid rgba(247,37,133,0.1)",
                }}
              >
                <div
                  className="d-flex align-items-center justify-content-center mx-auto"
                  style={{
                    position: "absolute",
                    top: "-16px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "32px",
                    height: "32px",
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, #4361ee, #f72585)",
                    color: "white",
                    fontSize: "13px",
                    fontWeight: "600",
                  }}
                >
                  2
                </div>
                <div
                  className="d-flex align-items-center justify-content-center mx-auto mb-3"
                  style={{
                    width: "64px",
                    height: "64px",
                    borderRadius: "18px",
                    background: "#fff0f7",
                  }}
                >
                  <svg
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#f72585"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="18" cy="5" r="3" />
                    <circle cx="6" cy="12" r="3" />
                    <circle cx="18" cy="19" r="3" />
                    <path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98" />
                  </svg>
                </div>
                <h5 className="font-weight-bold mb-2">Compartes tu link</h5>
                <p className="text-muted small mb-3">
                  Le das a tus clientes el link de tu agenda. Lo pones en
                  Instagram, WhatsApp o donde quieras.
                </p>
                <span
                  className="px-3 py-1"
                  style={{
                    background: "#fff0f7",
                    color: "#f72585",
                    borderRadius: "50px",
                    fontSize: "11px",
                    fontWeight: "600",
                  }}
                >
                  1 link, todo listo
                </span>
              </div>
            </Col>

            {/* Flecha 2 */}
            <Col
              md="1"
              className="d-none d-md-flex align-items-center justify-content-center"
              style={{ paddingTop: "52px" }}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#c7d0f8"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </Col>

            {/* Paso 3 */}
            <Col md="3">
              <div
                className="text-center p-4 position-relative"
                style={{
                  background: "#fff",
                  borderRadius: "20px",
                  border: "1px solid rgba(6,214,160,0.15)",
                }}
              >
                <div
                  className="d-flex align-items-center justify-content-center mx-auto"
                  style={{
                    position: "absolute",
                    top: "-16px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "32px",
                    height: "32px",
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, #4361ee, #f72585)",
                    color: "white",
                    fontSize: "13px",
                    fontWeight: "600",
                  }}
                >
                  3
                </div>
                <div
                  className="d-flex align-items-center justify-content-center mx-auto mb-3"
                  style={{
                    width: "64px",
                    height: "64px",
                    borderRadius: "18px",
                    background: "#edfff8",
                  }}
                >
                  <svg
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#06d6a0"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" />
                    <path d="M8 12l3 3 5-5" />
                  </svg>
                </div>
                <h5 className="font-weight-bold mb-2">
                  Las reservas llegan solas
                </h5>
                <p className="text-muted small mb-3">
                  Tus clientes reservan, reciben recordatorios automáticos y
                  acumulan puntos. Tú solo atiendes.
                </p>
                <span
                  className="px-3 py-1"
                  style={{
                    background: "#edfff8",
                    color: "#06d6a0",
                    borderRadius: "50px",
                    fontSize: "11px",
                    fontWeight: "600",
                  }}
                >
                  100% automático
                </span>
              </div>
            </Col>
          </Row>

          {/* CTA */}
          <div className="text-center mt-5">
            <Button
              size="lg"
              className="px-5 py-3 text-white"
              style={{
                background: "linear-gradient(135deg, #4361ee, #f72585)",
                border: "none",
                borderRadius: "50px",
                fontWeight: "600",
              }}
              onClick={() => (window.location.href = "/registro-negocio")}
            >
              Comenzar gratis — 7 días sin costo →
            </Button>
          </div>
        </Container>
      </section>

      {/* Sección: El problema que resolvemos */}
      <section className="py-6" style={{ background: "#f8f9fa" }}>
        <Container>
          <Row className="align-items-center">
            <Col lg="6" className="mb-4 mb-lg-0">
              <img
                src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800"
                alt="Profesional trabajando con tablet"
                className="img-fluid rounded-lg shadow"
                style={{ borderRadius: "20px" }}
              />
            </Col>
            <Col lg="6">
              <Badge
                className="mb-3 px-3 py-2"
                style={{
                  background: "#ffebee",
                  color: "#c62828",
                  borderRadius: "50px",
                }}
              >
                ⚠️ El problema
              </Badge>
              <h2 className="font-weight-bold mb-4">¿Suena familiar?</h2>
              <ul className="list-unstyled">
                <li className="mb-3 d-flex align-items-center">
                  <FiClock className="mr-3 text-danger" size={24} />
                  <span className="text-muted">
                    20 llamadas perdidas al día mientras atiendes
                  </span>
                </li>
                <li className="mb-3 d-flex align-items-center">
                  <FiMessageCircle className="mr-3 text-danger" size={24} />
                  <span className="text-muted">
                    50 mensajes de WhatsApp preguntando horarios
                  </span>
                </li>
                <li className="mb-3 d-flex align-items-center">
                  <FiUserX className="mr-3 text-danger" size={24} />
                  <span className="text-muted">
                    Clientes que no se acuerdan cuándo volver
                  </span>
                </li>
                <li className="mb-3 d-flex align-items-center">
                  <FiCalendar className="mr-3 text-danger" size={24} />
                  <span className="text-muted">
                    Horarios vacíos que podrían estar llenos
                  </span>
                </li>
              </ul>
              <p
                className="h5 font-weight-bold mt-4"
                style={{ color: "#4361ee" }}
              >
                Con AgendaFonfach, todo eso desaparece.
              </p>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Funcionalidades de la agenda */}
      <FuncionalidadesSection />
      <NegociosConfianza />

      {/* SECCIÓN COMBINADA: PLANES Y CONTACTO */}
      <section id="plan-contacto" className="py-7 bg-white">
        <Container>
          <div className="text-center mb-6">
            <Badge
              className="mb-3 px-3 py-2"
              style={{
                background: "linear-gradient(135deg, #4361ee 0%, #f72585 100%)",
                color: "white",
                borderRadius: "50px",
              }}
            >
              💎 Elige tu plan
            </Badge>
            <h2 className="display-4 font-weight-bold">
              Un plan para cada tamaño de negocio
            </h2>
            <p className="text-muted">
              Empieza solo y sube de plan a medida que crece tu equipo
            </p>
          </div>

          {/* Planes */}
          <Row className="justify-content-center mb-6">
            {planes.map((p, index) => (
              <Col lg="4" md="6" className="mb-4 d-flex" key={p.nombre}>
                <Card
                  className="border-0 shadow-lg w-100"
                  style={{
                    borderRadius: "30px",
                    overflow: "hidden",
                    border: p.destacado
                      ? "2px solid #f72585"
                      : "2px solid transparent",
                    transform: p.destacado ? "scale(1.03)" : "none",
                    zIndex: p.destacado ? 1 : 0,
                  }}
                >
                  {p.badge && (
                    <div
                      className="text-center py-2"
                      style={{
                        background: "#f72585",
                        color: "white",
                        fontSize: "12px",
                        fontWeight: "700",
                        letterSpacing: "0.5px",
                      }}
                    >
                      <FiStar className="mr-1" style={{ marginTop: "-2px" }} />
                      {p.badge.toUpperCase()}
                    </div>
                  )}

                  <div
                    className="p-4 text-center"
                    style={{
                      background: p.destacado
                        ? "linear-gradient(135deg, #4361ee 0%, #f72585 100%)"
                        : "#1a1a2e",
                    }}
                  >
                    <Badge
                      className="mb-3"
                      style={{
                        background: "rgba(255,255,255,0.2)",
                        color: "white",
                        border: "none",
                        borderRadius: "50px",
                        padding: "8px 16px",
                      }}
                    >
                      {p.nombre.toUpperCase()}
                    </Badge>
                    <h3 className="text-white mb-2">{p.subtitulo}</h3>

                    {p.precio ? (
                      <div className="d-flex align-items-center justify-content-center">
                        <span
                          className="text-white"
                          style={{ fontSize: "2.75rem", fontWeight: "bold" }}
                        >
                          ${p.precio}
                        </span>
                        <span className="text-white-50 ml-2">/{p.periodo}</span>
                      </div>
                    ) : (
                      <div
                        className="text-white"
                        style={{ fontSize: "1.75rem", fontWeight: "bold" }}
                      >
                        Precio a medida
                      </div>
                    )}
                  </div>

                  <CardBody className="p-4 d-flex flex-column">
                    <div className="mb-4 flex-grow-1">
                      {p.incluye.map((item, i) => (
                        <div key={i} className="d-flex align-items-center mb-3">
                          <FiCheckCircle
                            className="mr-3"
                            style={{
                              color: "#06d6a0",
                              fontSize: "1.2rem",
                              flexShrink: 0,
                            }}
                          />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>

                    <Button
                      block
                      className="text-white"
                      style={{
                        background: p.destacado
                          ? "linear-gradient(135deg, #4361ee, #f72585)"
                          : "#1a1a2e",
                        border: "none",
                        borderRadius: "10px",
                        padding: "12px",
                        fontWeight: "600",
                      }}
                      onClick={p.accion}
                    >
                      {p.cta} <FiArrowRight className="ml-2" />
                    </Button>

                    {index === 0 && (
                      <p className="text-center text-muted small mt-3 mb-0">
                        <FiShield className="mr-1" /> Sin permanencia. 7 días
                        gratis.
                      </p>
                    )}
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Footer */}
      <footer
        className="py-4"
        style={{ borderTop: "1px solid #eee", background: "#f8f9fa" }}
      >
        <Container>
          <Row className="align-items-center">
            <Col md="6" className="text-center text-md-left mb-3 mb-md-0">
              <div className="d-flex align-items-center justify-content-center justify-content-md-start">
                <FiCalendar style={{ color: "#f72585", fontSize: "1.5rem" }} />
                <span className="ml-2 font-weight-bold">AgendaFonfach</span>
              </div>
            </Col>

            <Col md="6" className="text-center text-md-right">
              <a
                href="https://instagram.com/hans.fonfach"
                target="_blank"
                rel="noopener noreferrer"
                className="mx-2"
              >
                <FiInstagram size={20} color="#4361ee" />
              </a>
              <a
                href="https://wa.me/56975297584"
                target="_blank"
                rel="noopener noreferrer"
                className="mx-2"
              >
                <FiSmartphone size={20} color="#25D366" />
              </a>
            </Col>
          </Row>

          <hr className="my-3" />

          <Row>
            <Col md="6" className="text-center text-md-left">
              <p className="text-muted small mb-0">
                © 2026 AgendaFonfach - Creado por Hans Fonfach.
              </p>
            </Col>
            <Col md="6" className="text-center text-md-right">
              <p className="text-muted small mb-0">
                ⚡ Desde $24.990 CLP - Sin comisiones - 7 días gratis
              </p>
            </Col>
          </Row>
        </Container>
      </footer>

      <style jsx>{`
        .hover-lift {
          transition: all 0.3s ease;
        }
        .hover-lift:hover {
          transform: translateY(-5px);
          box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1) !important;
        }
        .pt-9 {
          padding-top: 8rem;
        }
        .py-7 {
          padding-top: 6rem;
          padding-bottom: 6rem;
        }
        .mb-6 {
          margin-bottom: 4rem;
        }

        /* Mockup del hero */
        .hero-mockup-wrap {
          position: relative;
          max-width: 460px;
          margin: 0 auto;
        }
        .hero-mockup-card {
          background: #fff;
          border-radius: 24px;
          box-shadow: 0 30px 60px rgba(26, 26, 46, 0.15);
          overflow: hidden;
          border: 1px solid rgba(0, 0, 0, 0.04);
        }
        .mockup-topbar {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 14px 16px;
          background: #f8faff;
          border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        .mockup-dot {
          width: 9px;
          height: 9px;
          border-radius: 50%;
          display: inline-block;
        }
        .mockup-url {
          margin-left: 10px;
          font-size: 11px;
          color: #9aa3b2;
          background: #fff;
          padding: 3px 10px;
          border-radius: 6px;
          border: 1px solid rgba(0, 0, 0, 0.05);
        }
        .mockup-body {
          padding: 24px;
        }
        .mockup-header-row {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 20px;
        }
        .mockup-avatar {
          width: 46px;
          height: 46px;
          border-radius: 50%;
          background: linear-gradient(135deg, #eef1ff, #fce4f0);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.4rem;
          flex-shrink: 0;
        }
        .mockup-biz-name {
          font-weight: 700;
          color: #1a1a2e;
          font-size: 15px;
        }
        .mockup-biz-sub {
          font-size: 12px;
          color: #9aa3b2;
        }
        .mockup-days-row {
          display: flex;
          gap: 8px;
          margin-bottom: 14px;
        }
        .mockup-day-pill {
          flex: 1;
          text-align: center;
          padding: 8px 0;
          border-radius: 10px;
          font-size: 12px;
          font-weight: 600;
          color: #6c757d;
          background: #f4f6fb;
        }
        .mockup-day-pill.active {
          background: linear-gradient(135deg, #4361ee, #f72585);
          color: #fff;
        }
        .mockup-slots-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
          margin-bottom: 20px;
        }
        .mockup-slot {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 9px 0;
          border-radius: 10px;
          font-size: 12.5px;
          font-weight: 600;
          color: #4361ee;
          background: #eef1ff;
        }
        .mockup-slot.selected {
          background: #06d6a0;
          color: #fff;
        }
        .mockup-cta {
          width: 100%;
          padding: 13px;
          border-radius: 12px;
          background: linear-gradient(135deg, #4361ee, #f72585);
          color: #fff;
          font-weight: 600;
          font-size: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .floating-badge {
          position: absolute;
          display: flex;
          align-items: center;
          gap: 8px;
          background: #fff;
          padding: 10px 16px;
          border-radius: 50px;
          box-shadow: 0 12px 30px rgba(26, 26, 46, 0.15);
          font-size: 12.5px;
          font-weight: 600;
          color: #1a1a2e;
          animation: float-badge 3.5s ease-in-out infinite;
          white-space: nowrap;
        }
        .floating-whatsapp {
          top: -14px;
          left: -18px;
        }
        .floating-stat {
          bottom: -16px;
          right: -12px;
          animation-delay: 1.2s;
        }
        @keyframes float-badge {
          0%,
          100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-8px);
          }
        }
        @media (max-width: 767px) {
          .floating-badge {
            display: none;
          }
        }
      `}</style>
    </div>
  );
};

export default LandingPage;
