import React, { useState, useMemo, useEffect } from "react";
import {
  Container,
  Card,
  CardBody,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Input,
  Row,
  Col,
} from "reactstrap";
import { Info } from "lucide-react";
import { FaPhone } from "react-icons/fa";
import { useParams } from "react-router-dom";

import StepIndicator from "components/reserva/StepIndicator";
import ServicioSelector from "components/reserva/ServicioSelector";
import BarberoSelector from "components/reserva/BarberoSelector";
import WeekSelector from "components/reserva/WeekSelector";
import HorasDisponibles from "components/reserva/HorasDisponibles";
import ResumenReserva from "components/reserva/ResumenReserva";

import { useReservaInvitado } from "hooks/useReservaInvitado";
import AuthFooter from "components/Footers/AuthFooter";
import logo from "assets/img/logo4.png";
import { useRutValidator } from "hooks/useRutValidador";
import { useEmpresa } from "context/EmpresaContext";
import { getUsuarioByRutPublico } from "api/usuarios";

import { calcularPrecioFinal } from "utils/preciosServicios.js";
import {
  obtenerTemaEmpresa,
  TEMAS_LEGACY_POR_SLUG,
  TEMA_DEFAULT,
} from "utils/temaEmpresa";

// Esta página siempre mostraba el hero con texto blanco cuando no había un
// tema hecho a mano (fondo oscuro fijo) — se mantiene igual como respaldo
// para no cambiarle nada a los negocios que aún no configuran sus colores.
const TEMA_DEFAULT_RESERVA = {
  ...TEMA_DEFAULT,
  textDark: "#ffffff",
  textMuted: "rgba(255,255,255,0.9)",
};

const ReservarHoraInvitado = () => {
  const { slug } = useParams();
  const { empresa } = useEmpresa();

  // Usa los colores que el negocio haya configurado en
  // "Configuración → Colores" (empresa.colores). Si todavía no configuró
  // nada, cae al tema hecho a mano que tenía antes (o al default general).
  const theme = obtenerTemaEmpresa(empresa, slug, {
    temasLegacyPorSlug: TEMAS_LEGACY_POR_SLUG,
    temaDeFabrica: TEMA_DEFAULT_RESERVA,
  });
  const isLightTheme = theme.variant === "light";

  const {
    servicios,
    barberosFiltrados,
    servicio,
    barbero,
    fecha,
    hora,
    weekStart,
    weekDays,
    loadingWeek,
    horasDisponibles,
    cargandoHoras,
    mensajeHoras,
    horasDataCompleta,
    duracionServicio,
    invitado,
    setInvitado,
    loadingServicios,
    loadingBarberos,
    reservando,
    pasoActual,
    handleSeleccionarServicio,
    handleSeleccionarBarbero,
    handleSelectDay,
    prevWeek,
    nextWeek,
    setHora,
    reservarComoInvitado,
    codigoDescuento,
  } = useReservaInvitado(slug);

  const {
    rut: rutInvitado,
    handleRutChange,
    error: rutError,
  } = useRutValidator();

  const [modalInvitado, setModalInvitado] = useState(false);
  const toggleModalInvitado = () => setModalInvitado(!modalInvitado);
  const [buscandoUsuario, setBuscandoUsuario] = useState(false);
  const [usuarioEncontrado, setUsuarioEncontrado] = useState(false);
  const [usuarioData, setUsuarioData] = useState(null);

  useEffect(() => {
    setInvitado((prev) => ({ ...prev, rut: rutInvitado }));
    setUsuarioEncontrado(false);
    setUsuarioData(null);

    if (!rutError && rutInvitado.length >= 8) {
      const buscar = async () => {
        setBuscandoUsuario(true);
        try {
          const usuario = await getUsuarioByRutPublico(slug, rutInvitado);
          if (usuario) {
            setUsuarioData(usuario);
            setInvitado({
              rut: rutInvitado,
              nombre: usuario.nombre || "",
              apellido: usuario.apellido || "",
              telefono: "",
              email: "",
            });
            setUsuarioEncontrado(true);
          }
        } catch (err) {
        } finally {
          setBuscandoUsuario(false);
        }
      };
      buscar();
    }
  }, [rutInvitado, rutError]); // 👈 NO incluyas setInvitado aquí

  const invitadoValido =
    invitado.nombre &&
    invitado.apellido &&
    rutInvitado &&
    !rutError &&
    invitado.telefono?.length === 8 &&
    invitado.email;

  const servicioSeleccionado = useMemo(() => {
    if (!servicio) return null;
    return servicios.find((s) => String(s._id) === String(servicio)) || null;
  }, [servicio, servicios]);

  const barberoSeleccionado = useMemo(() => {
    // 👈 esto falta, agregalo
    if (!barbero) return null;
    return barberosFiltrados.find((b) => b._id === barbero) || null;
  }, [barbero, barberosFiltrados]);

  const precioFinalCalculado = useMemo(() => {
    if (!servicioSeleccionado) return null;

    // El precio real (con feriado/hora extra especial si corresponde) ya
    // viene calculado desde el backend para cada hora — es el mismo
    // cálculo que se usa al confirmar la reserva. Se prioriza ese valor.
    if (hora) {
      const horaSeleccionada = horasDisponibles?.find((h) => h.hora === hora);
      if (horaSeleccionada?.precio != null) return horaSeleccionada.precio;
    } else if (horasDisponibles?.length) {
      // Todavía no eligió hora: si TODAS las horas de ese día tienen el
      // mismo precio (el caso típico — precio especial de feriado que
      // rige el día completo), se puede mostrar de una vez. Si varían
      // (ej. una sola hora extra con precio distinto al resto del día),
      // se espera a que elija la hora exacta en vez de adivinar.
      const precios = new Set(
        horasDisponibles.filter((h) => h.precio != null).map((h) => h.precio),
      );
      if (precios.size === 1) return [...precios][0];
    }

    // Respaldo: cálculo local (solo descuentos por fecha del catálogo),
    // para cuando todavía no hay horas cargadas para ese día.
    return calcularPrecioFinal(servicioSeleccionado, fecha);
  }, [servicioSeleccionado, fecha, hora, horasDisponibles]);

  const progresoPasos = useMemo(() => {
    let pasos = 0;
    if (servicio) pasos++;
    if (barbero) pasos++;
    if (fecha) pasos++;
    if (hora) pasos++;
    return (pasos / 4) * 100;
  }, [servicio, barbero, fecha, hora]);

  if (loadingServicios) {
    return (
      <Container className="mt-7 py-5 text-center">
        <div
          className="spinner-border mb-3"
          role="status"
          style={{ color: theme.primary }}
        />
        <h5>Cargando disponibilidad</h5>
      </Container>
    );
  }

  return (
    <div style={{ backgroundColor: "#FFFFFF", overflowX: "hidden" }}>
      <div
        className="position-relative py-7 py-lg-8"
        style={{
          background: theme.heroBg,
          minHeight: "40vh",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Container>
          <Row className="justify-content-center text-center">
            <Col lg="8">
              {!isLightTheme && (
                <img
                  src={empresa?.logo || logo}
                  alt={empresa?.nombre || "Logo"}
                  className="img-fluid mb-4 floating"
                  style={{
                    width: "150px",
                    filter: "drop-shadow(0px 10px 15px rgba(0,0,0,0.3))",
                  }}
                />
              )}
              <div
                style={{
                  display: "inline-block",
                  backgroundColor: isLightTheme
                    ? theme.primaryLight
                    : "rgba(255,255,255,0.2)",
                  color: isLightTheme ? theme.primary : "#ffffff",
                  padding: "8px 20px",
                  borderRadius: "50px",
                  fontSize: "0.95rem",
                  marginBottom: "1.5rem",
                  fontWeight: 500,
                  border: isLightTheme
                    ? `1px solid ${theme.primary}30`
                    : "1px solid rgba(255,255,255,0.1)",
                  backdropFilter: isLightTheme ? "none" : "blur(10px)",
                }}
              >
                ✨ {empresa?.nombre || "Bienvenido"}
              </div>
              <h1
                className="display-2 font-weight-bold mb-2"
                style={{
                  color: isLightTheme ? theme.textDark : "#ffffff",
                  fontSize: "clamp(2.5rem, 6vw, 4rem)",
                  textShadow: isLightTheme
                    ? "none"
                    : "0 2px 10px rgba(0,0,0,0.2)",
                }}
              >
                Reserva tu hora
              </h1>
              <p
                className="lead"
                style={{
                  color: isLightTheme
                    ? theme.textMuted
                    : "rgba(255,255,255,0.9)",
                  fontSize: "1.25rem",
                  maxWidth: "600px",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              >
                Sin cuenta, sin complicaciones. Completa los pasos y asegura tu
                cita.
              </p>
            </Col>
          </Row>
        </Container>
      </div>

      <Container className="mt-5 mb-5" style={{ maxWidth: "1200px" }}>
        <div className="mb-4">
          <div className="d-flex justify-content-between">
            <span className="small text-muted">Progreso</span>
            <span className="small fw-bold" style={{ color: theme.primary }}>
              {Math.round(progresoPasos)}%
            </span>
          </div>
          <div className="progress" style={{ height: 6 }}>
            <div
              className="progress-bar"
              style={{
                width: `${progresoPasos}%`,
                backgroundColor: theme.primary,
              }}
            />
          </div>
        </div>

        <StepIndicator pasoActual={pasoActual} />

        <Card className="shadow-lg border-0">
          <div
            className="p-4 text-white"
            style={{
              background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.primaryDark} 100%)`,
            }}
          >
            <h3 className="mb-1">Reserva tu hora</h3>
            <small>Sin cuenta, sin complicaciones</small>
          </div>
          <CardBody className="p-4">
            <Row>
              <Col lg={7}>
                <ServicioSelector
                  servicios={servicios}
                  servicio={servicio}
                  onSeleccionarServicio={handleSeleccionarServicio}
                  slug={slug}
                />
                {servicio && (
                  <BarberoSelector
                    barberos={barberosFiltrados}
                    barbero={barbero}
                    loading={loadingBarberos}
                    onSeleccionarBarbero={handleSeleccionarBarbero}
                  />
                )}
                {servicio && barbero && (
                  <WeekSelector
                    weekStart={weekStart}
                    weekDays={weekDays}
                    loadingWeek={loadingWeek}
                    fecha={fecha}
                    onSelectDay={handleSelectDay}
                    onPrevWeek={prevWeek}
                    onNextWeek={nextWeek}
                    barberoId={barbero}
                    barberoInfo={barberoSeleccionado}
                  />
                )}
                {servicio && barbero && fecha && (
                  <HorasDisponibles
                    horasDisponibles={horasDisponibles}
                    mensajeHoras={mensajeHoras}
                    cargandoHoras={cargandoHoras}
                    hora={hora}
                    onSeleccionarHora={setHora}
                    fecha={fecha}
                    barberoId={barbero}
                    duracionSeleccionado={duracionServicio}
                    horasDataCompleta={horasDataCompleta}
                    esInvitado={true}
                  />
                )}
                {(!servicio || !barbero || !fecha || !hora) && (
                  <div className="mt-4 d-flex">
                    <Info className="me-2" style={{ color: theme.primary }} />
                    <small className="text-muted">
                      Sigue los pasos para completar tu reserva
                    </small>
                  </div>
                )}
              </Col>

              <Col lg={5}>
                <ResumenReserva
                  servicioSeleccionado={servicioSeleccionado}
                  precioFinalCalculado={precioFinalCalculado} // 👈 nuevo prop
                  barberoSeleccionado={barberoSeleccionado}
                  fecha={fecha}
                  hora={hora}
                  reservando={reservando}
                  onReservar={toggleModalInvitado}
                  codigoDescuento={codigoDescuento}
                  habilitado={servicio && barbero && fecha && hora}
                />
              </Col>
            </Row>
          </CardBody>
        </Card>

        <Modal isOpen={modalInvitado} toggle={toggleModalInvitado} centered>
          <ModalHeader toggle={toggleModalInvitado}>
            Datos del cliente
          </ModalHeader>

          <ModalBody autoComplete="off">
            <form autoComplete="off">
              <Input
                className={`mb-2 ${rutError ? "is-invalid" : ""}`}
                placeholder="Ingrese RUT sin puntos ni guión"
                value={rutInvitado}
                maxLength={12}
                onChange={handleRutChange}
                autoComplete="off"
                name="rut_fake"
              />

              {rutError && (
                <div className="invalid-feedback d-block mb-2">{rutError}</div>
              )}

              {buscandoUsuario && (
                <small className="text-muted d-block mb-2">
                  🔍 Buscando cliente...
                </small>
              )}
              {usuarioEncontrado && !buscandoUsuario && (
                <small className="d-block mb-2" style={{ color: theme.primary }}>
                  ✓ Datos completados automáticamente
                </small>
              )}

              <Input
                className="mb-2"
                placeholder="Nombre"
                value={invitado.nombre}
                autoComplete="off"
                name="nombre_fake"
                onChange={(e) => {
                  setUsuarioEncontrado(false);
                  setInvitado({ ...invitado, nombre: e.target.value });
                }}
              />

              <Input
                className="mb-2"
                placeholder="Apellido"
                value={invitado.apellido}
                autoComplete="off"
                name="apellido_fake"
                onChange={(e) =>
                  setInvitado({ ...invitado, apellido: e.target.value })
                }
              />

              <div className="mb-2">
                <div
                  className="d-flex align-items-center rounded input-group-alternative"
                  style={{
                    border: "1px solid #cad1d7",
                    backgroundColor: "#fff",
                  }}
                >
                  <div
                    className="d-flex align-items-center px-3 py-2"
                    style={{
                      backgroundColor: "#f7fafc",
                      borderRight: "1px solid #cad1d7",
                      whiteSpace: "nowrap",
                    }}
                  >
                    <FaPhone
                      size={13}
                      className="me-2"
                      style={{ color: theme.primary }}
                    />
                    <span
                      className="fw-bold text-dark"
                      style={{ fontSize: "0.85rem", color: theme.textMuted }}
                    >
                      +569
                    </span>
                  </div>

                  <input
                    placeholder="Teléfono"
                    type="text"
                    name="telefono_random"
                    autoComplete="new-password"
                    inputMode="numeric"
                    value={invitado.telefono}
                    onChange={(e) => {
                      let value = e.target.value.replace(/\D/g, "");
                      if (value.length > 8) value = value.slice(0, 8);
                      setInvitado({ ...invitado, telefono: value });
                    }}
                    className="form-control"
                    style={{
                      border: "none",
                      boxShadow: "none",
                      backgroundColor: "transparent",
                      padding: "0.65rem 0.75rem",
                      fontSize: "0.875rem",
                    }}
                  />

                  {invitado.telefono && (
                    <div className="px-2">
                      {invitado.telefono.length === 8 ? (
                        <span
                          className="fw-bold"
                          style={{ color: theme.primary }}
                        >
                          ✓
                        </span>
                      ) : (
                        <span className="text-muted small">
                          {invitado.telefono.length}/8
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {invitado.telefono && invitado.telefono.length !== 8 && (
                  <small className="text-danger ms-1">
                    El teléfono debe tener 8 dígitos
                  </small>
                )}
              </div>

              <Input
                className="mb-3"
                placeholder="Email"
                type="email"
                value={invitado.email}
                name="email_random"
                autoComplete="new-password"
                onChange={(e) =>
                  setInvitado({ ...invitado, email: e.target.value })
                }
              />

              <Button
                block
                disabled={!invitadoValido || reservando}
                style={{
                  backgroundColor: theme.primary,
                  border: "none",
                  fontWeight: 600,
                  borderRadius: "8px",
                  color: "#FFFFFF",
                }}
                onClick={async () => {
                  await reservarComoInvitado();
                  toggleModalInvitado();
                }}
              >
                {reservando ? "Reservando..." : "Confirmar reserva"}
              </Button>
            </form>
          </ModalBody>
        </Modal>
      </Container>

      <AuthFooter />
    </div>
  );
};

export default ReservarHoraInvitado;
