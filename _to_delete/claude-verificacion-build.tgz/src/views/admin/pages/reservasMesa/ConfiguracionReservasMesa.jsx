import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Button, Card, CardBody, CardHeader, Col, Container, FormGroup, Input, Label, Row, Spinner } from "reactstrap";
import Swal from "sweetalert2";
import { Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import UserHeader from "components/Headers/UserHeader.js";
import { useConfiguracionReservasMesa } from "hooks/useReservasMesa";
import { DIAS_SEMANA, mensajeError } from "utils/reservasMesa";

// Lunes primero, domingo al final
const ORDEN_DIAS = [1, 2, 3, 4, 5, 6, 0];

const numero = (v) => (v === "" || v === null || v === undefined ? "" : v);
const aNumero = (v) => (v === "" ? null : Number(v));

const Interruptor = ({ id, checked, onChange, children }) => (
  <div className="custom-control custom-switch mb-2">
    <input id={id} type="checkbox" className="custom-control-input" checked={!!checked} onChange={(e) => onChange(e.target.checked)} />
    <label className="custom-control-label" htmlFor={id}>
      {children}
    </label>
  </div>
);

const Seccion = ({ titulo, ayuda, children }) => (
  <Card className="shadow-sm mb-4">
    <CardHeader className="py-3">
      <h4 className="mb-0">{titulo}</h4>
      {ayuda && <small className="text-muted">{ayuda}</small>}
    </CardHeader>
    <CardBody>{children}</CardBody>
  </Card>
);

/** Configuración del módulo. Nada viene precargado: todo lo define el local. */
const ConfiguracionReservasMesa = () => {
  const { slug } = useParams();
  const { configuracion, faltantes, faltantesWeb, cargando, error, guardar } = useConfiguracionReservasMesa();
  const [form, setForm] = useState(null);
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    if (configuracion) setForm(JSON.parse(JSON.stringify(configuracion)));
  }, [configuracion]);

  if (cargando || !form) {
    return (
      <>
        <UserHeader />
        <Container className="mt--7 text-center" fluid>
          {error ? <div className="alert alert-danger">{error}</div> : <Spinner className="text-white" />}
        </Container>
      </>
    );
  }

  const set = (campo, valor) => setForm((f) => ({ ...f, [campo]: valor }));
  const setAnidado = (grupo, campo, valor) => setForm((f) => ({ ...f, [grupo]: { ...f[grupo], [campo]: valor } }));

  const setSector = (i, campo, valor) =>
    setForm((f) => ({ ...f, sectores: f.sectores.map((s, j) => (j === i ? { ...s, [campo]: valor } : s)) }));
  const agregarSector = () =>
    setForm((f) => ({ ...f, sectores: [...f.sectores, { nombre: "", capacidad: "", activo: true, reservableOnline: true }] }));
  const quitarSector = (i) => setForm((f) => ({ ...f, sectores: f.sectores.filter((_, j) => j !== i) }));
  const moverSector = (i, d) =>
    setForm((f) => {
      const s = [...f.sectores];
      const j = i + d;
      if (j < 0 || j >= s.length) return f;
      [s[i], s[j]] = [s[j], s[i]];
      return { ...f, sectores: s };
    });

  const dia = (n) => form.horario.find((h) => h.dia === n) || { dia: n, abierto: false, desde: null, hasta: null };
  const setDia = (n, campo, valor) =>
    setForm((f) => {
      const existe = f.horario.some((h) => h.dia === n);
      const horario = existe
        ? f.horario.map((h) => (h.dia === n ? { ...h, [campo]: valor } : h))
        : [...f.horario, { dia: n, abierto: false, desde: null, hasta: null, [campo]: valor }];
      return { ...f, horario };
    });

  const enviar = async () => {
    setGuardando(true);
    try {
      const cuerpo = {
        ...form,
        sectores: form.sectores.map((s) => ({ ...s, capacidad: aNumero(s.capacidad) })),
      };
      const r = await guardar(cuerpo);
      Swal.fire({
        icon: "success",
        title: "Configuración guardada",
        text: r.faltantes?.length ? `Aún falta: ${r.faltantes.join(", ")}.` : "Ya se pueden registrar reservas.",
      });
    } catch (e) {
      Swal.fire("No se pudo guardar", mensajeError(e), "error");
    } finally {
      setGuardando(false);
    }
  };

  const linkPublico = `${window.location.origin}/${slug}/reservar-mesa`;

  return (
    <>
      <UserHeader />
      <Container className="mt--7" fluid>
        <Row className="justify-content-center">
          <Col xl="9">
            <Card className="shadow mb-4">
              <CardBody className="d-flex flex-wrap justify-content-between align-items-center" style={{ gap: 12 }}>
                <div>
                  <h3 className="mb-0">Configuración de reservas de mesa</h3>
                  {faltantes?.length ? (
                    <small className="text-warning">Falta: {faltantes.join(", ")}</small>
                  ) : (
                    <small className="text-success">Lista para recibir reservas</small>
                  )}
                </div>
                <Button color="primary" className="m-0" disabled={guardando} onClick={enviar}>
                  {guardando ? "Guardando..." : "Guardar"}
                </Button>
              </CardBody>
            </Card>

            <Seccion
              titulo="Sectores"
              ayuda="Capacidad = personas que se pueden reservar al mismo tiempo. Si quieres dejar lugar para quien llega sin reserva, pon un número menor que la capacidad real."
            >
              {form.sectores.length === 0 && <p className="text-muted">Todavía no hay sectores.</p>}
              {form.sectores.map((s, i) => (
                <div key={s._id || `nuevo-${i}`} className="border rounded p-3 mb-2">
                  <Row className="align-items-end">
                    <Col xs="12" md="5" className="mb-2">
                      <Label className="small">Nombre</Label>
                      <Input value={s.nombre} maxLength={40} placeholder="Ej: Terraza" onChange={(e) => setSector(i, "nombre", e.target.value)} />
                    </Col>
                    <Col xs="6" md="3" className="mb-2">
                      <Label className="small">Capacidad (personas)</Label>
                      <Input type="number" min="1" value={numero(s.capacidad)} onChange={(e) => setSector(i, "capacidad", e.target.value)} />
                    </Col>
                    <Col xs="6" md="4" className="mb-2 d-flex justify-content-end" style={{ gap: 6 }}>
                      <Button size="sm" outline className="m-0" onClick={() => moverSector(i, -1)} disabled={i === 0} aria-label="Subir">
                        <ArrowUp size={14} />
                      </Button>
                      <Button size="sm" outline className="m-0" onClick={() => moverSector(i, 1)} disabled={i === form.sectores.length - 1} aria-label="Bajar">
                        <ArrowDown size={14} />
                      </Button>
                      <Button size="sm" outline color="danger" className="m-0" onClick={() => quitarSector(i)} aria-label="Quitar">
                        <Trash2 size={14} />
                      </Button>
                    </Col>
                  </Row>
                  <div className="d-flex flex-wrap" style={{ columnGap: 24 }}>
                    <Interruptor id={`s-activo-${i}`} checked={s.activo} onChange={(v) => setSector(i, "activo", v)}>
                      Activo
                    </Interruptor>
                    <Interruptor id={`s-web-${i}`} checked={s.reservableOnline} onChange={(v) => setSector(i, "reservableOnline", v)}>
                      Se puede reservar por la web
                    </Interruptor>
                  </div>
                </div>
              ))}
              <Button size="sm" outline color="primary" className="m-0" onClick={agregarSector}>
                <Plus size={14} style={{ verticalAlign: "-2px" }} /> Agregar sector
              </Button>
            </Seccion>

            <Seccion
              titulo="Horario de llegadas"
              ayuda="Primera y última hora a la que puede llegar una reserva. La reserva puede terminar después (según su duración)."
            >
              {ORDEN_DIAS.map((n) => {
                const d = dia(n);
                return (
                  <Row key={n} className="align-items-center border-bottom py-2 mx-0">
                    <Col xs="12" sm="4" className="px-0">
                      <Interruptor id={`dia-${n}`} checked={d.abierto} onChange={(v) => setDia(n, "abierto", v)}>
                        {DIAS_SEMANA[n]}
                      </Interruptor>
                    </Col>
                    {d.abierto ? (
                      <>
                        <Col xs="6" sm="4" className="pl-0">
                          <Input type="time" bsSize="sm" step="900" value={d.desde || ""} onChange={(e) => setDia(n, "desde", e.target.value)} />
                        </Col>
                        <Col xs="6" sm="4" className="pr-0">
                          <Input type="time" bsSize="sm" step="900" value={d.hasta || ""} onChange={(e) => setDia(n, "hasta", e.target.value)} />
                        </Col>
                      </>
                    ) : (
                      <Col xs="12" sm="8" className="text-muted small px-0">
                        No se reciben reservas
                      </Col>
                    )}
                  </Row>
                );
              })}
            </Seccion>

            <Seccion titulo="Reglas de reserva">
              <Row>
                <Col md="6">
                  <FormGroup>
                    <Label>Horas ofrecidas cada</Label>
                    <Input type="select" value={numero(form.intervaloMinutos)} onChange={(e) => set("intervaloMinutos", aNumero(e.target.value))}>
                      <option value="">Elegir</option>
                      <option value="15">15 minutos</option>
                      <option value="30">30 minutos</option>
                      <option value="60">60 minutos</option>
                    </Input>
                  </FormGroup>
                </Col>
                <Col md="6">
                  <FormGroup>
                    <Label>Duración de la reserva (minutos)</Label>
                    <Input type="number" min="15" step="15" value={numero(form.duracionMinutos)} onChange={(e) => set("duracionMinutos", aNumero(e.target.value))} />
                    <small className="text-muted">Cuánto tiempo se guarda el lugar. Múltiplo de 15.</small>
                  </FormGroup>
                </Col>
                <Col md="6">
                  <FormGroup>
                    <Label>Anticipación mínima por la web (minutos)</Label>
                    <Input type="number" min="0" value={numero(form.anticipacionMinimaMinutos)} onChange={(e) => set("anticipacionMinimaMinutos", aNumero(e.target.value))} />
                    <small className="text-muted">El panel puede registrar llegadas inmediatas.</small>
                  </FormGroup>
                </Col>
                <Col md="6">
                  <FormGroup>
                    <Label>Anticipación máxima (días)</Label>
                    <Input type="number" min="1" value={numero(form.anticipacionMaximaDias)} onChange={(e) => set("anticipacionMaximaDias", aNumero(e.target.value))} />
                  </FormGroup>
                </Col>
                <Col md="6">
                  <FormGroup>
                    <Label>Máximo de personas por reserva</Label>
                    <Input type="number" min="1" value={numero(form.maxPersonasPorReserva)} onChange={(e) => set("maxPersonasPorReserva", aNumero(e.target.value))} />
                  </FormGroup>
                </Col>
                <Col md="6">
                  <FormGroup>
                    <Label>Tolerancia de atraso (minutos)</Label>
                    <Input type="number" min="0" value={numero(form.toleranciaMinutos)} onChange={(e) => set("toleranciaMinutos", aNumero(e.target.value))} />
                    <small className="text-muted">Después de esto la reserva aparece como atrasada.</small>
                  </FormGroup>
                </Col>
              </Row>
            </Seccion>

            <Seccion titulo="Reservas por la web">
              <Interruptor id="web-activa" checked={form.reservasWebActivas} onChange={(v) => set("reservasWebActivas", v)}>
                Recibir reservas desde la página pública
              </Interruptor>
              {faltantesWeb?.length > 0 && form.reservasWebActivas && (
                <div className="small text-warning mb-2">Para activarla falta: {faltantesWeb.filter((f) => f !== "Reservas web activadas").join(", ")}</div>
              )}
              <div className="small mb-3">
                Link para compartir:{" "}
                <a href={linkPublico} target="_blank" rel="noreferrer">
                  {linkPublico}
                </a>
              </div>
              <Row>
                <Col md="6">
                  <FormGroup>
                    <Label>Máximo de personas por reserva web</Label>
                    <Input type="number" min="1" value={numero(form.maxPersonasWeb)} onChange={(e) => set("maxPersonasWeb", aNumero(e.target.value))} />
                    <small className="text-muted">Los grupos más grandes ven tu teléfono para contactarte.</small>
                  </FormGroup>
                </Col>
                <Col md="6" className="pt-md-4">
                  <Interruptor id="web-auto" checked={form.confirmacionAutomaticaWeb} onChange={(v) => set("confirmacionAutomaticaWeb", v)}>
                    Confirmar automáticamente (si no, quedan pendientes hasta que las confirmes)
                  </Interruptor>
                </Col>
              </Row>
              <FormGroup>
                <Label>Mensaje en la página de reservas (opcional)</Label>
                <Input type="textarea" rows="2" maxLength={600} value={form.mensajePublico} onChange={(e) => set("mensajePublico", e.target.value)} />
              </FormGroup>
              <FormGroup>
                <Label>Mensaje para cumpleaños (opcional)</Label>
                <Input type="textarea" rows="2" maxLength={300} value={form.mensajeCumpleanos} placeholder="Ej: lo que ofrece el local o lo que pueden traer" onChange={(e) => set("mensajeCumpleanos", e.target.value)} />
              </FormGroup>

              <hr className="my-3" />
              <Interruptor id="cancel-web" checked={form.cancelacionWeb?.permitida} onChange={(v) => setAnidado("cancelacionWeb", "permitida", v)}>
                El cliente puede cancelar con el link de su correo
              </Interruptor>
              {form.cancelacionWeb?.permitida && (
                <FormGroup style={{ maxWidth: 320 }}>
                  <Label>Hasta cuántas horas antes</Label>
                  <Input type="number" min="0" value={numero(form.cancelacionWeb.horasLimite)} onChange={(e) => setAnidado("cancelacionWeb", "horasLimite", aNumero(e.target.value))} />
                </FormGroup>
              )}

              <Interruptor id="recordatorio" checked={form.recordatorio?.activo} onChange={(v) => setAnidado("recordatorio", "activo", v)}>
                Enviar recordatorio por correo
              </Interruptor>
              {form.recordatorio?.activo && (
                <FormGroup style={{ maxWidth: 320 }}>
                  <Label>Cuántas horas antes</Label>
                  <Input type="number" min="1" max="72" value={numero(form.recordatorio.horasAntes)} onChange={(e) => setAnidado("recordatorio", "horasAntes", aNumero(e.target.value))} />
                </FormGroup>
              )}
            </Seccion>

            <Seccion titulo="Permisos del personal" ayuda="El administrador siempre puede todo. El resto del equipo puede ver, registrar, editar y marcar llegadas.">
              <Interruptor id="perm-cancelar" checked={form.permisosPersonal?.cancelar} onChange={(v) => setAnidado("permisosPersonal", "cancelar", v)}>
                El personal puede cancelar reservas
              </Interruptor>
              <Interruptor id="perm-sobrecupo" checked={form.permisosPersonal?.forzarSobrecupo} onChange={(v) => setAnidado("permisosPersonal", "forzarSobrecupo", v)}>
                El personal puede registrar con sobrecupo
              </Interruptor>
            </Seccion>

            <div className="text-right mb-5">
              <Button color="primary" disabled={guardando} onClick={enviar}>
                {guardando ? "Guardando..." : "Guardar configuración"}
              </Button>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default ConfiguracionReservasMesa;
